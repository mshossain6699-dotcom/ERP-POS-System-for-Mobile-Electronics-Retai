/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Category,
  Brand,
  Customer,
  Supplier,
  Sale,
  Purchase,
  Expense,
  Account,
  Transaction,
  Coupon,
  Partner,
  StockAdjustment,
  Notification,
  ShopSettings,
} from '../types';

interface AppContextProps {
  products: Product[];
  categories: Category[];
  brands: Brand[];
  customers: Customer[];
  suppliers: Supplier[];
  sales: Sale[];
  purchases: Purchase[];
  expenses: Expense[];
  accounts: Account[];
  transactions: Transaction[];
  coupons: Coupon[];
  partners: Partner[];
  stockAdjustments: StockAdjustment[];
  notifications: Notification[];
  settings: ShopSettings;
  
  // Handlers
  addProduct: (product: Omit<Product, 'id'>) => Product;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  bulkImportProducts: (imported: Array<Omit<Product, 'id' | 'status'>>) => void;
  
  addCategory: (name: string, description?: string) => void;
  addBrand: (name: string) => void;
  
  addCustomer: (customer: Omit<Customer, 'id' | 'totalSpent' | 'dueBalance'>) => Customer;
  updateCustomer: (customer: Customer) => void;
  
  addSupplier: (supplier: Omit<Supplier, 'id' | 'dueBalance'>) => Supplier;
  updateSupplier: (supplier: Supplier) => void;
  
  addSale: (sale: Omit<Sale, 'id' | 'invoiceNo'>) => void;
  addPurchase: (purchase: Omit<Purchase, 'id'>) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  
  addAccount: (account: Omit<Account, 'id' | 'balance'>) => void;
  transferFunds: (fromId: string, toId: string, amount: number, memo: string) => boolean;
  depositWithdraw: (accountId: string, type: 'Deposit' | 'Withdrawal', amount: number, memo: string) => boolean;
  
  addCoupon: (coupon: Omit<Coupon, 'id'>) => void;
  toggleCouponActive: (id: string) => void;
  
  addPartner: (partner: Omit<Partner, 'id' | 'balanceDrawing'>) => void;
  updatePartner: (partner: Partner) => void;
  
  addStockAdjustment: (adj: Omit<StockAdjustment, 'id' | 'date'>) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  updateSettings: (settings: ShopSettings) => void;
}

const AppContext = createContext<AppContextProps | undefined>(undefined);

// Helper for unique ID generation
const genId = () => Math.random().toString(36).substring(2, 9).toUpperCase();

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // --- 1. DEFAULT MOCK DATA ---
  const initialCategories: Category[] = [
    { id: 'CAT-1', name: 'Smartphones', description: 'Interactive Android & iOS mobile devices' },
    { id: 'CAT-2', name: 'Feature Phones', description: 'Button-style durable low-cost mobile phones' },
    { id: 'CAT-3', name: 'Accessories', description: 'Chargers, Glass protectors, Earbuds, Powerbanks' },
  ];

  const initialBrands: Brand[] = [
    { id: 'BR-1', name: 'Apple' },
    { id: 'BR-2', name: 'Samsung' },
    { id: 'BR-3', name: 'Xiaomi' },
    { id: 'BR-4', name: 'Realme' },
    { id: 'BR-5', name: 'Anker' },
    { id: 'BR-6', name: 'Symphony' },
  ];

  const initialProducts: Product[] = [
    {
      id: 'PROD-1',
      name: 'iPhone 15 Pro Max',
      model: '15 Pro Max',
      brand: 'Apple',
      category: 'Smartphones',
      costPrice: 135000,
      sellingPrice: 148000,
      quantity: 5,
      imeis: ['IMEI-15PM-001', 'IMEI-15PM-002', 'IMEI-15PM-003', 'IMEI-15PM-004', 'IMEI-15PM-005'],
      color: 'Natural Titanium',
      ram: '8GB',
      storage: '256GB',
      isPhone: true,
      lowStockLimit: 2,
      status: 'In Stock'
    },
    {
      id: 'PROD-2',
      name: 'Galaxy S24 Ultra',
      model: 'S24 Ultra',
      brand: 'Samsung',
      category: 'Smartphones',
      costPrice: 118000,
      sellingPrice: 129500,
      quantity: 3,
      imeis: ['IMEI-S24U-771', 'IMEI-S24U-772', 'IMEI-S24U-773'],
      color: 'Titanium Gray',
      ram: '12GB',
      storage: '512GB',
      isPhone: true,
      lowStockLimit: 2,
      status: 'In Stock'
    },
    {
      id: 'PROD-3',
      name: 'Redmi Note 13 Pro 5G',
      model: 'Note 13 Pro',
      brand: 'Xiaomi',
      category: 'Smartphones',
      costPrice: 31000,
      sellingPrice: 34500,
      quantity: 12,
      imeis: [
        'IMEI-RN13-101', 'IMEI-RN13-102', 'IMEI-RN13-103', 'IMEI-RN13-104',
        'IMEI-RN13-105', 'IMEI-RN13-106', 'IMEI-RN13-107', 'IMEI-RN13-108',
        'IMEI-RN13-109', 'IMEI-RN13-110', 'IMEI-RN13-111', 'IMEI-RN13-112'
      ],
      color: 'Midnight Black',
      ram: '8GB',
      storage: '256GB',
      isPhone: true,
      lowStockLimit: 4,
      status: 'In Stock'
    },
    {
      id: 'PROD-4',
      name: 'Realme GT Neo 6 SE',
      model: 'GT Neo 6 SE',
      brand: 'Realme',
      category: 'Smartphones',
      costPrice: 28500,
      sellingPrice: 32000,
      quantity: 1,
      imeis: ['IMEI-RGT6-091'], // Low stock trigger
      color: 'Liquid Silver',
      ram: '12GB',
      storage: '256GB',
      isPhone: true,
      lowStockLimit: 3,
      status: 'Low Stock'
    },
    {
      id: 'PROD-5',
      name: 'Symphony BL120',
      model: 'BL120',
      brand: 'Symphony',
      category: 'Feature Phones',
      costPrice: 1200,
      sellingPrice: 1550,
      quantity: 0,
      imeis: [], // Out of stock trigger
      color: 'Royal Blue',
      ram: '32MB',
      storage: '64MB',
      isPhone: true,
      lowStockLimit: 5,
      status: 'Out of Stock'
    },
    {
      id: 'PROD-6',
      name: 'Anker PowerPort III USB-C Charger',
      model: '20W Nano',
      brand: 'Anker',
      category: 'Accessories',
      costPrice: 1100,
      sellingPrice: 1650,
      quantity: 45,
      imeis: [], // Not a phone, general item
      color: 'White',
      ram: 'N/A',
      storage: 'N/A',
      isPhone: false,
      lowStockLimit: 10,
      status: 'In Stock'
    },
  ];

  const initialCustomers: Customer[] = [
    { id: 'CUST-WALK', name: 'Walk-in Customer', phone: '01XXXXXXXXX', email: 'walkin@shop.com', address: 'Sales Desk', totalSpent: 125000, dueBalance: 0 },
    { id: 'CUST-1', name: 'Rahat Jamil', phone: '01712345678', email: 'rahat@gmail.com', address: 'Uttara, Dhaka', totalSpent: 148000, dueBalance: 0 },
    { id: 'CUST-2', name: 'Sadia Tabassum', phone: '01898765432', email: 'sadia.t@yahoo.com', address: 'Dhanmondi, Dhaka', totalSpent: 34500, dueBalance: 5000 },
    { id: 'CUST-3', name: 'Naimur Rahman', phone: '01511223344', email: 'naimur@outlook.com', address: 'Mirpur, Dhaka', totalSpent: 1650, dueBalance: 0 },
  ];

  const initialSuppliers: Supplier[] = [
    { id: 'SUPP-1', name: 'Dhaka Mobile Distributors Ltd', phone: '01900112233', email: 'sales@dhakamobile.bd', company: 'Dhaka Mobile Group', dueBalance: 120000 },
    { id: 'SUPP-2', name: 'Anker Official importer BD', phone: '01799998888', email: 'supply@ankerbd.com', company: 'Anker Bangladesh Ltd', dueBalance: 0 },
    { id: 'SUPP-3', name: 'Gen Nex Accessories', phone: '01866554433', email: 'gennex@hotmail.com', company: 'GenNex Distribution', dueBalance: 0 },
  ];

  const initialAccounts: Account[] = [
    { id: 'ACC-1', name: 'Cash Register (Drawer)', type: 'Cash', balance: 45000 },
    { id: 'ACC-2', name: 'bKash Merchant Account', type: 'MFS', accountNo: '01855441122', balance: 145200 },
    { id: 'ACC-3', name: 'Nagad Business Wallet', type: 'MFS', accountNo: '01912341234', balance: 68000 },
    { id: 'ACC-4', name: 'BRAC Bank Business A/C', type: 'Bank', accountNo: '1501204481230001', balance: 520000 },
  ];

  const initialCoupons: Coupon[] = [
    { id: 'COUP-1', code: 'EID2026', discountType: 'Flat', discountValue: 2000, minPurchase: 40000, expiryDate: '2026-07-31', isActive: true },
    { id: 'COUP-2', code: 'BONUS10', discountType: 'Percentage', discountValue: 10, minPurchase: 1000, expiryDate: '2026-08-15', isActive: true },
    { id: 'COUP-3', code: 'WELCOME500', discountType: 'Flat', discountValue: 500, minPurchase: 5000, expiryDate: '2026-12-31', isActive: false },
  ];

  const initialPartners: Partner[] = [
    { id: 'PART-1', name: 'Zahid Hasan (CEO)', sharePercentage: 60, capitalContributed: 400000, balanceDrawing: 150000 },
    { id: 'PART-2', name: 'Farhan Kabir (Silent)', sharePercentage: 40, capitalContributed: 300000, balanceDrawing: 80000 },
  ];

  const initialSettings: ShopSettings = {
    shopName: 'NeoTech Mobile & Gadgets',
    address: 'Shop 45, Level 5, Block B, Bashundhara City Shopping Mall, Panthapath, Dhaka',
    contactNo: '01712-345678',
    currency: '৳',
    vatPercent: 5,
    invoiceFooter: 'Thank you for choosing NeoTech. Original IMEI verified. 1 Year warranty as standard, void of physical damage.',
    bkashMerchantNo: '01855441122',
    nagadMerchantNo: '01912341234',
    rocketNo: '01512345678',
    targetMonthlySales: 1500000,
  };

  // Helper date generators for realistic sales historical data (past 7 days)
  const getPastDateString = (daysAgo: number): string => {
    const d = new Date();
    d.setDate(d.getDate() - daysAgo);
    return d.toISOString().split('T')[0]; // YYYY-MM-DD
  };

  const initialSales: Sale[] = [
    {
      id: 'SALE-1',
      invoiceNo: 'INV-2026-001',
      date: getPastDateString(6),
      customerId: 'CUST-1',
      customerName: 'Rahat Jamil',
      customerPhone: '01712345678',
      items: [
        {
          productId: 'PROD-1',
          productName: 'iPhone 15 Pro Max',
          model: '15 Pro Max',
          price: 148000,
          quantity: 1,
          discount: 1000,
          imeis: ['IMEI-15PM-005'],
          isPhone: true
        }
      ],
      subtotal: 148000,
      couponCode: 'EID2026',
      couponDiscount: 2000,
      taxAmount: 7300, // 5% of (148k - 3k)
      total: 152300,
      paidAmount: 152300,
      dueAmount: 0,
      paymentMethod: 'BRAC Bank Business A/C' as any, // mapping to Name
      notes: 'Came for eid offer, self pickup.'
    },
    {
      id: 'SALE-2',
      invoiceNo: 'INV-2026-002',
      date: getPastDateString(5),
      customerId: 'CUST-2',
      customerName: 'Sadia Tabassum',
      customerPhone: '01898765432',
      items: [
        {
          productId: 'PROD-3',
          productName: 'Redmi Note 13 Pro 5G',
          model: 'Note 13 Pro',
          price: 34500,
          quantity: 1,
          discount: 500,
          imeis: ['IMEI-RN13-112'],
          isPhone: true
        }
      ],
      subtotal: 34500,
      couponDiscount: 0,
      taxAmount: 1700,
      total: 35700,
      paidAmount: 30700,
      dueAmount: 5000,
      paymentMethod: 'bKash Merchant Account' as any,
      notes: 'Client promised to clear due inside 15 days.'
    },
    {
      id: 'SALE-3',
      invoiceNo: 'INV-2026-004',
      date: getPastDateString(4),
      customerId: 'CUST-WALK',
      customerName: 'Walk-in Customer',
      customerPhone: '01XXXXXXXXX',
      items: [
        {
          productId: 'PROD-6',
          productName: 'Anker PowerPort III USB-C Charger',
          model: '20W Nano',
          price: 1650,
          quantity: 2,
          discount: 100,
          imeis: [],
          isPhone: false
        }
      ],
      subtotal: 3300,
      couponDiscount: 0,
      taxAmount: 155,
      total: 3355,
      paidAmount: 3355,
      dueAmount: 0,
      paymentMethod: 'Cash Register (Drawer)' as any,
    },
    {
      id: 'SALE-4',
      invoiceNo: 'INV-2026-005',
      date: getPastDateString(3),
      customerId: 'CUST-WALK',
      customerName: 'Walk-in Customer',
      customerPhone: '01XXXXXXXXX',
      items: [
        {
          productId: 'PROD-2',
          productName: 'Galaxy S24 Ultra',
          model: 'S24 Ultra',
          price: 129500,
          quantity: 1,
          discount: 1500,
          imeis: ['IMEI-S24U-773'],
          isPhone: true
        }
      ],
      subtotal: 129500,
      couponDiscount: 0,
      taxAmount: 6400,
      total: 134400,
      paidAmount: 134400,
      dueAmount: 0,
      paymentMethod: 'BRAC Bank Business A/C' as any,
    },
    {
      id: 'SALE-5',
      invoiceNo: 'INV-2026-006',
      date: getPastDateString(2),
      customerId: 'CUST-WALK',
      customerName: 'Walk-in Customer',
      customerPhone: '01XXXXXXXXX',
      items: [
        {
          productId: 'PROD-3',
          productName: 'Redmi Note 13 Pro 5G',
          model: 'Note 13 Pro',
          price: 34500,
          quantity: 1,
          discount: 0,
          imeis: ['IMEI-RN13-111'],
          isPhone: true
        },
        {
          productId: 'PROD-6',
          productName: 'Anker PowerPort III USB-C Charger',
          model: '20W Nano',
          price: 1650,
          quantity: 1,
          discount: 150,
          imeis: [],
          isPhone: false
        }
      ],
      subtotal: 36150,
      couponDiscount: 0,
      taxAmount: 1800,
      total: 37800,
      paidAmount: 37800,
      dueAmount: 0,
      paymentMethod: 'bKash Merchant Account' as any,
    },
    {
      id: 'SALE-6',
      invoiceNo: 'INV-2026-007',
      date: getPastDateString(1),
      customerId: 'CUST-WALK',
      customerName: 'Walk-in Customer',
      customerPhone: '01XXXXXXXXX',
      items: [
        {
          productId: 'PROD-3',
          productName: 'Redmi Note 13 Pro 5G',
          model: 'Note 13 Pro',
          price: 34500,
          quantity: 2,
          discount: 500,
          imeis: ['IMEI-RN13-109', 'IMEI-RN13-110'],
          isPhone: true
        }
      ],
      subtotal: 69000,
      couponDiscount: 0,
      taxAmount: 3400,
      total: 71900,
      paidAmount: 71900,
      dueAmount: 0,
      paymentMethod: 'Nagad Business Wallet' as any,
    },
    // Today's Sales
    {
      id: 'SALE-7',
      invoiceNo: 'INV-2026-008',
      date: getPastDateString(0),
      customerId: 'CUST-WALK',
      customerName: 'Walk-in Customer',
      customerPhone: '01XXXXXXXXX',
      items: [
        {
          productId: 'PROD-3',
          productName: 'Redmi Note 13 Pro 5G',
          model: 'Note 13 Pro',
          price: 34500,
          quantity: 1,
          discount: 500,
          imeis: ['IMEI-RN13-108'],
          isPhone: true
        },
        {
          productId: 'PROD-6',
          productName: 'Anker PowerPort III USB-C Charger',
          model: '20W Nano',
          price: 1650,
          quantity: 1,
          discount: 50,
          imeis: [],
          isPhone: false
        }
      ],
      subtotal: 36150,
      couponDiscount: 0,
      taxAmount: 1780,
      total: 37830,
      paidAmount: 37830,
      dueAmount: 0,
      paymentMethod: 'Cash Register (Drawer)' as any,
    }
  ];

  const initialPurchases: Purchase[] = [
    {
      id: 'PUR-1',
      date: getPastDateString(10),
      supplierId: 'SUPP-1',
      supplierName: 'Dhaka Mobile Distributors Ltd',
      items: [
        {
          productId: 'PROD-1',
          productName: 'iPhone 15 Pro Max',
          costPrice: 135000,
          quantity: 4,
          imeis: ['IMEI-15PM-001', 'IMEI-15PM-002', 'IMEI-15PM-003', 'IMEI-15PM-004']
        }
      ],
      total: 540000,
      paidAmount: 420000,
      dueAmount: 120000,
      paymentMethod: 'BRAC Bank Business A/C',
      notes: 'Initial restock of flagships for June. Due to settle soon.'
    }
  ];

  const initialExpenses: Expense[] = [
    { id: 'EXP-1', date: getPastDateString(8), description: 'Shop Space Hire Rent', category: 'Rent', amount: 25000, paymentAccount: 'BRAC Bank Business A/C' },
    { id: 'EXP-2', date: getPastDateString(4), description: 'Electricity Bill May 2026', category: 'Utilities', amount: 4800, paymentAccount: 'Cash Register (Drawer)' },
    { id: 'EXP-3', date: getPastDateString(1), description: 'Staff Lunch and Tea snacks', category: 'Entertainment', amount: 1200, paymentAccount: 'Cash Register (Drawer)' },
  ];

  const initialTransactions: Transaction[] = [
    { id: 'TX-1', date: getPastDateString(8), accountId: 'ACC-4', type: 'Expense', amount: 25000, description: 'Shop Space Hire Rent ERP Ref EXP-1', refId: 'EXP-1' },
    { id: 'TX-2', date: getPastDateString(4), accountId: 'ACC-1', type: 'Expense', amount: 4800, description: 'Electricity Bill May 2026 ERP Ref EXP-2', refId: 'EXP-2' },
    { id: 'TX-3', date: getPastDateString(1), accountId: 'ACC-1', type: 'Expense', amount: 1200, description: 'Staff Lunch and Tea snacks ERP Ref EXP-3', refId: 'EXP-3' },
    { id: 'TX-4', date: getPastDateString(10), accountId: 'ACC-4', type: 'Purchase', amount: 420000, description: 'Paid to Dhaka Mobile Distributors Ref PUR-1', refId: 'PUR-1' },
    { id: 'TX-5', date: getPastDateString(6), accountId: 'ACC-4', type: 'Sale', amount: 152300, description: 'Paid for INV-2026-001 by Rahat Jamil', refId: 'SALE-1' },
    { id: 'TX-6', date: getPastDateString(5), accountId: 'ACC-2', type: 'Sale', amount: 30700, description: 'Paid for INV-2026-002 by Sadia Tabassum', refId: 'SALE-2' },
    { id: 'TX-7', date: getPastDateString(4), accountId: 'ACC-1', type: 'Sale', amount: 3355, description: 'Paid for INV-2026-004 Walker', refId: 'SALE-3' },
    { id: 'TX-8', date: getPastDateString(3), accountId: 'ACC-4', type: 'Sale', amount: 134400, description: 'Paid for INV-2026-005 Walker', refId: 'SALE-4' },
    { id: 'TX-9', date: getPastDateString(2), accountId: 'ACC-2', type: 'Sale', amount: 37800, description: 'Paid for INV-2026-006 Walker', refId: 'SALE-5' },
    { id: 'TX-10', date: getPastDateString(1), accountId: 'ACC-3', type: 'Sale', amount: 71900, description: 'Paid for INV-2026-007 Walker', refId: 'SALE-6' },
    { id: 'TX-11', date: getPastDateString(0), accountId: 'ACC-1', type: 'Sale', amount: 37830, description: 'Paid for INV-2026-008 WalkerToday', refId: 'SALE-7' },
  ];

  const initialStockAdjustments: StockAdjustment[] = [
    { id: 'SADJ-1', date: getPastDateString(12), productId: 'PROD-3', productName: 'Redmi Note 13 Pro 5G', type: 'Addition', quantity: 2, reason: 'Manual audit match correction', adjustedBy: 'Store Manager' }
  ];

  const initialNotifications: Notification[] = [
    { id: 'NOT-1', date: getPastDateString(1), message: 'Realme GT Neo 6 SE is at low stock level (1 remaining). Please restock.', type: 'LowStock', read: false },
    { id: 'NOT-2', date: getPastDateString(0), message: 'Symphony BL120 is fully out of stock.', type: 'LowStock', read: false },
  ];

  // --- 2. STATE STORAGE & SYNCHRONIZATION ---
  const loadState = <T,>(key: string, defaultValue: T): T => {
    try {
      const stored = localStorage.getItem(`mobileshop_erp_${key}`);
      return stored ? JSON.parse(stored) : defaultValue;
    } catch (e) {
      console.error(`Error loading state for ${key}`, e);
      return defaultValue;
    }
  };

  const [categories, setCategories] = useState<Category[]>(() => loadState('categories', initialCategories));
  const [brands, setBrands] = useState<Brand[]>(() => loadState('brands', initialBrands));
  const [products, setProducts] = useState<Product[]>(() => loadState('products', initialProducts));
  const [customers, setCustomers] = useState<Customer[]>(() => loadState('customers', initialCustomers));
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => loadState('suppliers', initialSuppliers));
  const [sales, setSales] = useState<Sale[]>(() => loadState('sales', initialSales));
  const [purchases, setPurchases] = useState<Purchase[]>(() => loadState('purchases', initialPurchases));
  const [expenses, setExpenses] = useState<Expense[]>(() => loadState('expenses', initialExpenses));
  const [accounts, setAccounts] = useState<Account[]>(() => loadState('accounts', initialAccounts));
  const [transactions, setTransactions] = useState<Transaction[]>(() => loadState('transactions', initialTransactions));
  const [coupons, setCoupons] = useState<Coupon[]>(() => loadState('coupons', initialCoupons));
  const [partners, setPartners] = useState<Partner[]>(() => loadState('partners', initialPartners));
  const [stockAdjustments, setStockAdjustments] = useState<StockAdjustment[]>(() => loadState('stockAdjustments', initialStockAdjustments));
  const [notifications, setNotifications] = useState<Notification[]>(() => loadState('notifications', initialNotifications));
  const [settings, setSettings] = useState<ShopSettings>(() => {
    const loaded = loadState('settings', initialSettings);
    return { ...initialSettings, ...loaded };
  });

  // Sync to local storage
  useEffect(() => { localStorage.setItem('mobileshop_erp_categories', JSON.stringify(categories)); }, [categories]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_brands', JSON.stringify(brands)); }, [brands]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_customers', JSON.stringify(customers)); }, [customers]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_suppliers', JSON.stringify(suppliers)); }, [suppliers]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_sales', JSON.stringify(sales)); }, [sales]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_purchases', JSON.stringify(purchases)); }, [purchases]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_expenses', JSON.stringify(expenses)); }, [expenses]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_accounts', JSON.stringify(accounts)); }, [accounts]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_coupons', JSON.stringify(coupons)); }, [coupons]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_partners', JSON.stringify(partners)); }, [partners]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_stockAdjustments', JSON.stringify(stockAdjustments)); }, [stockAdjustments]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_notifications', JSON.stringify(notifications)); }, [notifications]);
  useEffect(() => { localStorage.setItem('mobileshop_erp_settings', JSON.stringify(settings)); }, [settings]);


  // --- 3. CRUD HANDLERS AND HELPER ACTIONS ---

  const addCategory = (name: string, description?: string) => {
    const newCat: Category = { id: `CAT-${genId()}`, name, description };
    setCategories(prev => [...prev, newCat]);
  };

  const addBrand = (name: string) => {
    const newBrand: Brand = { id: `BR-${genId()}`, name };
    setBrands(prev => [...prev, newBrand]);
  };

  const addProduct = (product: Omit<Product, 'id'>) => {
    const id = `PROD-${genId()}`;
    // Determine status
    let status: Product['status'] = 'In Stock';
    if (product.quantity === 0) status = 'Out of Stock';
    else if (product.quantity <= product.lowStockLimit) status = 'Low Stock';
    
    const newProd: Product = { ...product, id, status };
    setProducts(prev => [...prev, newProd]);

    // Notification if low/out of stock
    if (status === 'Out of Stock' || status === 'Low Stock') {
      const not: Notification = {
        id: `NOT-${genId()}`,
        date: new Date().toISOString().split('T')[0],
        message: `${newProd.name} is ${status.toLowerCase()} (${newProd.quantity} left).`,
        type: 'LowStock',
        read: false
      };
      setNotifications(prev => [not, ...prev]);
    }
    return newProd;
  };

  const updateProduct = (updated: Product) => {
    setProducts(prev => prev.map(p => {
      if (p.id === updated.id) {
        let status: Product['status'] = 'In Stock';
        if (updated.quantity === 0) status = 'Out of Stock';
        else if (updated.quantity <= updated.lowStockLimit) status = 'Low Stock';
        
        const nextProd = { ...updated, status };
        
        // Push notification on state change
        if (status !== p.status && (status === 'Out of Stock' || status === 'Low Stock')) {
          const not: Notification = {
            id: `NOT-${genId()}`,
            date: new Date().toISOString().split('T')[0],
            message: `${updated.name} has dropped to ${status.toLowerCase()} (${updated.quantity} remaining).`,
            type: 'LowStock',
            read: false
          };
          setNotifications(n => [not, ...n]);
        }
        return nextProd;
      }
      return p;
    }));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const bulkImportProducts = (imported: Array<Omit<Product, 'id' | 'status'>>) => {
    const processed: Product[] = imported.map(item => {
      let status: Product['status'] = 'In Stock';
      if (item.quantity === 0) status = 'Out of Stock';
      else if (item.quantity <= item.lowStockLimit) status = 'Low Stock';

      return {
        ...item,
        id: `PROD-${genId()}`,
        status,
      };
    });

    setProducts(prev => [...prev, ...processed]);

    // Send notifications for any low stock items in bulk import
    const newNotifs: Notification[] = [];
    processed.forEach(p => {
      if (p.status === 'Low Stock' || p.status === 'Out of Stock') {
        newNotifs.push({
          id: `NOT-${genId()}`,
          date: new Date().toISOString().split('T')[0],
          message: `Bulk Imported: ${p.name} is added in ${p.status.toLowerCase()} state (${p.quantity} left).`,
          type: 'LowStock',
          read: false
        });
      }
    });

    if (newNotifs.length > 0) {
      setNotifications(prev => [...newNotifs, ...prev]);
    }
  };

  const addCustomer = (customer: Omit<Customer, 'id' | 'totalSpent' | 'dueBalance'>) => {
    const id = `CUST-${genId()}`;
    const newCust: Customer = { ...customer, id, totalSpent: 0, dueBalance: 0 };
    setCustomers(prev => [...prev, newCust]);
    return newCust;
  };

  const updateCustomer = (updated: Customer) => {
    setCustomers(prev => prev.map(c => c.id === updated.id ? updated : c));
  };

  const addSupplier = (supplier: Omit<Supplier, 'id' | 'dueBalance'>) => {
    const id = `SUPP-${genId()}`;
    const newSupp: Supplier = { ...supplier, id, dueBalance: 0 };
    setSuppliers(prev => [...prev, newSupp]);
    return newSupp;
  };

  const updateSupplier = (updated: Supplier) => {
    setSuppliers(prev => prev.map(s => s.id === updated.id ? updated : s));
  };

  const addSale = (saleData: Omit<Sale, 'id' | 'invoiceNo'>) => {
    const id = `SALE-${genId()}`;
    const year = new Date().getFullYear();
    const count = sales.length + 1;
    const invoiceNo = `INV-${year}-${count.toString().padStart(3, '0')}`;
    const fullSale: Sale = { ...saleData, id, invoiceNo };
    
    // 1. Update Product stocks and filter out sold IMEIs
    setProducts(prevProducts => {
      return prevProducts.map(p => {
        const soldItem = saleData.items.find(item => item.productId === p.id);
        if (soldItem) {
          const nextQty = Math.max(0, p.quantity - soldItem.quantity);
          const nextImeis = p.isPhone
            ? p.imeis.filter(i => !soldItem.imeis.includes(i))
            : p.imeis;
          
          let status: Product['status'] = 'In Stock';
          if (nextQty === 0) status = 'Out of Stock';
          else if (nextQty <= p.lowStockLimit) status = 'Low Stock';

          return { ...p, quantity: nextQty, imeis: nextImeis, status };
        }
        return p;
      });
    });

    // 2. Clear sold / alert low stock if any
    saleData.items.forEach(item => {
      const p = products.find(x => x.id === item.productId);
      if (p) {
        const nextQty = p.quantity - item.quantity;
        if (nextQty <= p.lowStockLimit) {
          const statText = nextQty === 0 ? 'Out of Stock' : 'Low Stock';
          setNotifications(prev => [{
            id: `NOT-${genId()}`,
            date: saleData.date,
            message: `Stock Alert: ${p.name} drops to ${statText.toLowerCase()} (${nextQty} units left).`,
            type: 'LowStock',
            read: false
          }, ...prev]);
        }
      }
    });

    // 3. Update Customer total spent and due balances
    if (saleData.customerId !== 'CUST-WALK') {
      setCustomers(prev => prev.map(c => {
        if (c.id === saleData.customerId) {
          return {
            ...c,
            totalSpent: c.totalSpent + saleData.total,
            dueBalance: c.dueBalance + saleData.dueAmount,
          };
        }
        return c;
      }));
    }

    // 4. Update Financial Account Balance & Create Transaction history
    if (saleData.paidAmount > 0) {
      // Find matching account by name (since paymentMethod in pos holds account name or type)
      setAccounts(prevAccts => prevAccts.map(acc => {
        if (acc.name === (saleData.paymentMethod as any)) {
          return { ...acc, balance: acc.balance + saleData.paidAmount };
        }
        return acc;
      }));

      // Add to transactions list
      const matchedAccountObj = accounts.find(a => a.name === (saleData.paymentMethod as any));
      const accId = matchedAccountObj ? matchedAccountObj.id : 'ACC-1'; 
      
      const tx: Transaction = {
        id: `TX-${genId()}`,
        date: saleData.date,
        accountId: accId,
        type: 'Sale',
        amount: saleData.paidAmount,
        description: `Customer payment for ${invoiceNo} (Direct POS Sale)`,
        refId: id
      };
      setTransactions(prev => [tx, ...prev]);
    }

    // Append sale to list
    setSales(prev => [fullSale, ...prev]);

    // Check if monthly sales target achieved or progress alerts
    const totalMonthSales = sales
      .filter(s => s.date.substring(0, 7) === saleData.date.substring(0, 7))
      .reduce((sum, s) => sum + s.total, 0) + saleData.total;
    
    if (totalMonthSales >= settings.targetMonthlySales && (totalMonthSales - saleData.total) < settings.targetMonthlySales) {
      setNotifications(prev => [{
        id: `NOT-${genId()}`,
        date: saleData.date,
        message: `🎉 KPI Target Met! Monthly sales reached ৳${totalMonthSales.toLocaleString()} exceeding target of ৳${settings.targetMonthlySales.toLocaleString()}.`,
        type: 'Target',
        read: false
      }, ...prev]);
    }
  };

  const addPurchase = (purchaseData: Omit<Purchase, 'id'>) => {
    const id = `PUR-${genId()}`;
    const fullPurchase: Purchase = { ...purchaseData, id };
    
    // 1. Add Stock Quantity & update IMEIs for products
    setProducts(prevProducts => {
      return prevProducts.map(p => {
        const item = purchaseData.items.find(x => x.productId === p.id);
        if (item) {
          const nextQty = p.quantity + item.quantity;
          const nextImeis = p.isPhone ? [...p.imeis, ...item.imeis] : p.imeis;

          let status: Product['status'] = 'In Stock';
          if (nextQty === 0) status = 'Out of Stock';
          else if (nextQty <= p.lowStockLimit) status = 'Low Stock';

          return {
            ...p,
            quantity: nextQty,
            imeis: nextImeis,
            status,
            costPrice: item.costPrice // update default cost price to latest
          };
        }
        return p;
      });
    });

    // 2. Adjust supplier outstanding bill
    setSuppliers(prev => prev.map(s => {
      if (s.id === purchaseData.supplierId) {
        return { ...s, dueBalance: s.dueBalance + purchaseData.dueAmount };
      }
      return s;
    }));

    // 3. Deduct from account wallet
    if (purchaseData.paidAmount > 0) {
      // Assume deducted from Cash or BRAC Bank
      const payAccName = purchaseData.paymentMethod || 'BRAC Bank Business A/C';
      setAccounts(prev => prev.map(a => {
        if (a.name === payAccName) {
          return { ...a, balance: a.balance - purchaseData.paidAmount };
        }
        return a;
      }));

      const targetAccount = accounts.find(a => a.name === payAccName) || accounts[3]; // Fallback to BRAC Bank
      const tx: Transaction = {
        id: `TX-${genId()}`,
        date: purchaseData.date,
        accountId: targetAccount.id,
        type: 'Purchase',
        amount: purchaseData.paidAmount,
        description: `Paid to supplier (${purchaseData.supplierName}) for stock delivery`,
        refId: id
      };
      setTransactions(prev => [tx, ...prev]);
    }

    setPurchases(prev => [fullPurchase, ...prev]);
  };

  const addExpense = (expData: Omit<Expense, 'id'>) => {
    const id = `EXP-${genId()}`;
    const fullExp: Expense = { ...expData, id };

    // 1. Deduct account balance
    setAccounts(prev => prev.map(acc => {
      if (acc.name === expData.paymentAccount) {
        return { ...acc, balance: Math.max(0, acc.balance - expData.amount) };
      }
      return acc;
    }));

    // 2. Log transaction
    const matched = accounts.find(a => a.name === expData.paymentAccount) || accounts[0];
    const tx: Transaction = {
      id: `TX-${genId()}`,
      date: expData.date,
      accountId: matched.id,
      type: 'Expense',
      amount: expData.amount,
      description: `Shop Expense: ${expData.description} [${expData.category}]`,
      refId: id
    };

    setExpenses(prev => [fullExp, ...prev]);
    setTransactions(prev => [tx, ...prev]);
  };

  const addAccount = (accData: Omit<Account, 'id' | 'balance'>) => {
    const id = `ACC-${genId()}`;
    const newAcc: Account = { ...accData, id, balance: 0 };
    setAccounts(prev => [...prev, newAcc]);
  };

  const transferFunds = (fromId: string, toId: string, amount: number, memo: string): boolean => {
    const sender = accounts.find(a => a.id === fromId);
    if (!sender || sender.balance < amount) {
      return false; // Insufficient
    }

    const todayStr = new Date().toISOString().split('T')[0];

    // Deduct and Deposit
    setAccounts(prev => prev.map(a => {
      if (a.id === fromId) return { ...a, balance: a.balance - amount };
      if (a.id === toId) return { ...a, balance: a.balance + amount };
      return a;
    }));

    // Two Transaction logs
    const receiver = accounts.find(a => a.id === toId)!;
    const txOut: Transaction = {
      id: `TX-${genId()}`,
      date: todayStr,
      accountId: fromId,
      type: 'Tfr Out',
      amount,
      description: `Transfer Out to ${receiver?.name || ''}. Memo: ${memo}`
    };

    const txIn: Transaction = {
      id: `TX-${genId()}`,
      date: todayStr,
      accountId: toId,
      type: 'Tfr In',
      amount,
      description: `Transfer In from ${sender.name}. Memo: ${memo}`
    };

    setTransactions(prev => [txOut, txIn, ...prev]);
    return true;
  };

  const depositWithdraw = (accountId: string, type: 'Deposit' | 'Withdrawal', amount: number, memo: string): boolean => {
    const acc = accounts.find(a => a.id === accountId);
    if (!acc) return false;
    if (type === 'Withdrawal' && acc.balance < amount) return false;

    const todayStr = new Date().toISOString().split('T')[0];

    setAccounts(prev => prev.map(a => {
      if (a.id === accountId) {
        return {
          ...a,
          balance: type === 'Deposit' ? a.balance + amount : a.balance - amount
        };
      }
      return a;
    }));

    const tx: Transaction = {
      id: `TX-${genId()}`,
      date: todayStr,
      accountId,
      type: type,
      amount,
      description: `Manual Account ${type}: ${memo}`
    };

    setTransactions(prev => [tx, ...prev]);
    return true;
  };

  const addCoupon = (coupon: Omit<Coupon, 'id'>) => {
    const id = `COUP-${genId()}`;
    setCoupons(prev => [...prev, { ...coupon, id }]);
  };

  const toggleCouponActive = (id: string) => {
    setCoupons(prev => prev.map(c => c.id === id ? { ...c, isActive: !c.isActive } : c));
  };

  const addPartner = (pData: Omit<Partner, 'id' | 'balanceDrawing'>) => {
    const id = `PART-${genId()}`;
    const newPartner: Partner = { ...pData, id, balanceDrawing: 0 };
    setPartners(prev => [...prev, newPartner]);
  };

  const updatePartner = (updated: Partner) => {
    setPartners(prev => prev.map(p => p.id === updated.id ? updated : p));
  };

  const addStockAdjustment = (adj: Omit<StockAdjustment, 'id' | 'date'>) => {
    const id = `SADJ-${genId()}`;
    const date = new Date().toISOString().split('T')[0];
    const fullAdj: StockAdjustment = { ...adj, id, date };

    // Update Product Quantities
    setProducts(prev => prev.map(p => {
      if (p.id === adj.productId) {
        const adjustmentQty = adj.type === 'Addition' ? adj.quantity : -adj.quantity;
        const nextQty = Math.max(0, p.quantity + adjustmentQty);
        
        let status: Product['status'] = 'In Stock';
        if (nextQty === 0) status = 'Out of Stock';
        else if (nextQty <= p.lowStockLimit) status = 'Low Stock';

        return { ...p, quantity: nextQty, status };
      }
      return p;
    }));

    setStockAdjustments(prev => [fullAdj, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const clearNotifications = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const updateSettings = (updated: ShopSettings) => {
    setSettings(updated);
  };

  return (
    <AppContext.Provider
      value={{
        products,
        categories,
        brands,
        customers,
        suppliers,
        sales,
        purchases,
        expenses,
        accounts,
        transactions,
        coupons,
        partners,
        stockAdjustments,
        notifications,
        settings,
        
        addProduct,
        updateProduct,
        deleteProduct,
        bulkImportProducts,
        
        addCategory,
        addBrand,
        
        addCustomer,
        updateCustomer,
        
        addSupplier,
        updateSupplier,
        
        addSale,
        addPurchase,
        addExpense,
        
        addAccount,
        transferFunds,
        depositWithdraw,
        
        addCoupon,
        toggleCouponActive,
        
        addPartner,
        updatePartner,
        
        addStockAdjustment,
        markNotificationRead,
        clearNotifications,
        updateSettings,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used inside an AppProvider');
  }
  return context;
};
