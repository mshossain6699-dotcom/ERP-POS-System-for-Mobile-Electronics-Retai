/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Upload, X, Copy, Check, FileText, AlertCircle, RefreshCw } from 'lucide-react';
import { Product } from '../types';

interface BulkImportDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (products: Array<Omit<Product, 'id' | 'status'>>) => void;
}

interface ParsedRow {
  name: string;
  model: string;
  brand: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  ram: string;
  storage: string;
  color: string;
  quantity: number;
  imeis: string[];
  isPhone: boolean;
  isValid: boolean;
  errors: string[];
}

export const BulkImportDialog: React.FC<BulkImportDialogProps> = ({ isOpen, onClose, onImport }) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [pasteText, setPasteText] = useState('');
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [errorMessage, setErrorMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Template columns info
  const templateHeaders = [
    'Product Name',
    'Model',
    'Brand',
    'Category',
    'Cost Price',
    'Selling Price',
    'RAM',
    'Storage',
    'Color',
    'Quantity',
    'IMEIs (Semicolon separated)'
  ];

  const sampleTSV = `Samsung Galaxy A55\tA55\tSamsung\tSmartphones\t38000\t41500\t8GB\t256GB\tAwesome Iceblue\t3\tIMEI-GA55-0901;IMEI-GA55-0902;IMEI-GA55-0903\nXiaomi Poco X6 Pro\tPoco X6 Pro\tXiaomi\tSmartphones\t32000\t35500\t12GB\t512GB\tSpectre Yellow\t2\tIMEI-PX6-8871;IMEI-PX6-8872\nAnker 65W Pod\t65W Charger\tAnker\tAccessories\t2400\t3200\tN/A\tN/A\tBlack\t10\t`;

  const copyTemplateToClipboard = () => {
    navigator.clipboard.writeText(sampleTSV);
    alert('Sample spreadsheet data copied! You can paste it directly in the text tab.');
  };

  // Parsing & validation engine
  const parseRawLines = (lines: string[], delimiter: string) => {
    const rowsList: ParsedRow[] = [];
    setErrorMessage('');

    lines.forEach((line, index) => {
      // Skip empty lines or headers
      if (!line.trim()) return;
      
      const cols = line.split(delimiter).map(c => c.replace(/^["']|["']$/g, '').trim());
      
      // If header row is pasted, ignore it
      if (index === 0 && cols[0].toLowerCase().includes('name') && cols[1].toLowerCase().includes('model')) {
        return;
      }

      // We expect around 10-11 columns
      if (cols.length < 6) return;

      const name = cols[0] || '';
      const model = cols[1] || '';
      const brand = cols[2] || 'Generic';
      const category = cols[3] || 'Smartphones';
      const costPrice = parseFloat(cols[4]) || 0;
      const sellingPrice = parseFloat(cols[5]) || 0;
      const ram = cols[6] || 'N/A';
      const storage = cols[7] || 'N/A';
      const color = cols[8] || 'Generic';
      const quantity = parseInt(cols[9], 10) || 0;
      
      // Extract IMEIs
      const rawImeisCol = cols[10] || '';
      const imeis = rawImeisCol
        ? rawImeisCol.split(';').map(i => i.trim()).filter(i => i.length > 0)
        : [];

      // Logic check
      const isPhone = category.toLowerCase().includes('phone') || category.toLowerCase().includes('smartphone');
      const errors: string[] = [];

      if (!name) errors.push('Product Name is required');
      if (!model) errors.push('Model designation is required');
      if (costPrice <= 0) errors.push('Cost Price must be greater than 0 BDT');
      if (sellingPrice <= 0) errors.push('Selling Price must be greater than 0 BDT');
      if (sellingPrice < costPrice) errors.push('Selling price is lower than cost price (Warning)');
      
      if (isPhone) {
        if (quantity !== imeis.length) {
          errors.push(`IMEI Count mismatch! Qty is ${quantity} but provided ${imeis.length} IMEIs in list`);
        }
      }

      rowsList.push({
        name,
        model,
        brand,
        category,
        costPrice,
        sellingPrice,
        ram,
        storage,
        color,
        quantity,
        imeis,
        isPhone,
        isValid: errors.filter(e => !e.includes('Warning')).length === 0,
        errors
      });
    });

    setParsedRows(rowsList);
  };

  // Paste handler
  const handlePasteChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setPasteText(text);

    const lines = text.split('\n');
    // guess delimiter: default to TSV tabs, or comma
    const hasTabs = text.includes('\t');
    parseRawLines(lines, hasTabs ? '\t' : ',');
  };

  // CSV File reader handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      const lines = text.split('\n');
      // comma vs semicolon vs tab delimiter detection
      let delim = ',';
      if (text.includes('\t')) delim = '\t';
      else if (text.includes(';')) delim = ';';
      
      parseRawLines(lines, delim);
    };
    reader.readAsText(file);
  };

  // Action Import
  const handleExecuteImport = () => {
    const validRows = parsedRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      setErrorMessage('No valid rows found in CSV or text grid to import.');
      return;
    }

    const payload = validRows.map(r => ({
      name: r.name,
      model: r.model,
      brand: r.brand,
      category: r.category,
      costPrice: r.costPrice,
      sellingPrice: r.sellingPrice,
      quantity: r.quantity,
      imeis: r.imeis,
      color: r.color,
      ram: r.ram,
      storage: r.storage,
      isPhone: r.isPhone,
      lowStockLimit: r.isPhone ? 3 : 10
    }));

    onImport(payload);
    // Success clean states
    setParsedRows([]);
    setPasteText('');
    setErrorMessage('');
    onClose();
    alert(`Success! Bulk imported ${payload.length} products to your inventory!`);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header bar */}
        <div className="px-6 py-4 border-b border-slate-800 flex justify-between items-center bg-slate-950/30">
          <div className="flex items-center gap-2">
            <Upload className="text-indigo-400" size={20} />
            <div>
              <h3 className="text-sm font-bold text-slate-100">Smart Device Bulk Importer</h3>
              <p className="text-[10px] text-slate-400">Import hundreds of mobile products & Serial IMEI listings in seconds</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Outer instructions panel */}
        <div className="bg-slate-950/40 px-6 py-3 border-b border-slate-800/60 flex flex-wrap justify-between items-center gap-3">
          <div className="text-[11px] text-slate-300 leading-normal max-w-2xl">
            <span className="font-bold text-amber-400">Required format:</span> copy-paste tabular rows directly from Microsoft Excel or Google Sheets. Columns must list: 
            <span className="text-indigo-300 font-mono text-[10px] block mt-1">
              Name → Model → Brand → Category → CostPrice → SellingPrice → RAM → Storage → Color → Qty → IMEIs (separated by semicolon)
            </span>
          </div>
          <button
            onClick={copyTemplateToClipboard}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 hover:text-indigo-400 transition-all cursor-pointer"
          >
            <Copy size={13} />
            <span>Copy Mock Sample Excel</span>
          </button>
        </div>

        {/* Tab selection */}
        <div className="border-b border-slate-800 flex">
          <button
            onClick={() => { setActiveTab('upload'); setParsedRows([]); }}
            className={`px-5 py-3 text-xs font-bold border-b-2 hover:text-slate-100 transition-colors ${
              activeTab === 'upload' ? 'border-indigo-500 text-indigo-400 bg-slate-850/30' : 'border-transparent text-slate-400'
            }`}
          >
            CSV File Upload
          </button>
          <button
            onClick={() => { setActiveTab('paste'); setParsedRows([]); }}
            className={`px-5 py-3 text-xs font-bold border-b-2 hover:text-slate-100 transition-colors ${
              activeTab === 'paste' ? 'border-indigo-500 text-indigo-400 bg-slate-850/30' : 'border-transparent text-slate-400'
            }`}
          >
            Direct Copy-Paste Grid
          </button>
        </div>

        <div className="p-6 flex-1 overflow-y-auto space-y-4">
          {/* Main workspace */}
          {activeTab === 'upload' ? (
            <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-xl py-8 px-4 text-center cursor-pointer hover:border-slate-700 transition-colors bg-slate-950/20"
                 onClick={() => fileInputRef.current?.click()}>
              <FileText className="text-slate-500 mb-2" size={32} />
              <p className="text-xs font-bold text-slate-200">Drag & Drop or Click to Upload CSV Table</p>
              <p className="text-[10px] text-slate-400 mt-1">Accepts standard .csv or .tsv reports</p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.tsv,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          ) : (
            <div className="flex flex-col space-y-1.5">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Paste spreadsheet tables below:</label>
              <textarea
                placeholder="Paste your copied columns from Microsoft Excel/Sheets here..."
                rows={5}
                value={pasteText}
                onChange={handlePasteChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono placeholder:text-slate-600 focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
          )}

          {/* Validation Table */}
          {parsedRows.length > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Spreadsheet Preview ({parsedRows.length} rows detected)
                </span>
                <span className="text-xs font-semibold text-emerald-400">
                  {parsedRows.filter(r => r.isValid).length} ready to import successfully
                </span>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-hidden max-h-60 overflow-y-auto">
                <table className="w-full text-left text-[11px] border-collapse bg-slate-950/40">
                  <thead className="bg-slate-950 sticky top-0 text-slate-400 border-b border-slate-850">
                    <tr>
                      <th className="py-2 px-3">Device / Name</th>
                      <th className="py-2 px-3">Model Specs</th>
                      <th className="py-2 px-3">Category</th>
                      <th className="py-2 px-3 text-right">Selling Price</th>
                      <th className="py-2 px-3 text-right">Quantity</th>
                      <th className="py-2 px-3">IMEI Numbers Check</th>
                      <th className="py-2 px-3 text-center">Import State</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {parsedRows.map((row, index) => (
                      <tr key={index} className={`hover:bg-slate-800/20 ${row.isValid ? 'text-slate-300' : 'text-slate-500 bg-red-950/5'}`}>
                        <td className="py-2 px-3 font-semibold text-slate-200">
                          {row.name}
                          <span className="block text-[9px] text-slate-400 font-normal">{row.brand}</span>
                        </td>
                        <td className="py-2 px-3 font-mono">
                          {row.ram}/{row.storage} • {row.color}
                        </td>
                        <td className="py-2 px-3">{row.category}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-100">
                          ৳{row.sellingPrice.toLocaleString()}
                        </td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-indigo-400">
                          {row.quantity}
                        </td>
                        <td className="py-2 px-3">
                          {row.imeis.length > 0 ? (
                            <div className="flex flex-wrap gap-1 max-w-[200px]">
                              {row.imeis.map((imei, iIdx) => (
                                <span key={iIdx} className="bg-slate-800 border border-slate-700/60 text-[9px] px-1 rounded text-slate-300 font-mono">
                                  {imei}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-slate-500 italic">None (accessories)</span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-center">
                          {row.isValid ? (
                            <span className="text-emerald-400 font-bold flex items-center justify-center gap-1">
                              <Check size={12} /> Validated
                            </span>
                          ) : (
                            <div className="flex flex-col items-center justify-center text-rose-400 select-none cursor-help group relative">
                              <span className="font-bold flex items-center gap-1">
                                <AlertCircle size={12} /> Failed
                              </span>
                              <div className="hidden group-hover:block absolute bottom-6 right-0 bg-slate-950 border border-rose-500/30 text-[9px] w-48 p-1.5 rounded shadow-xl leading-tight text-white font-normal z-50 whitespace-pre-line text-left">
                                {row.errors.join('\n')}
                              </div>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 flex items-center gap-2 text-xs text-red-400">
              <AlertCircle size={14} />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Footer controls */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/30 flex justify-between items-center">
          <div className="text-xs text-slate-400">
            {parsedRows.length > 0 && (
              <span>
                Processed:{' '}
                <strong className="text-indigo-400 font-bold">
                  {parsedRows.filter(r => r.isValid).length}
                </strong>{' '}
                / {parsedRows.length} rows successfully matched format.
              </span>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-slate-800 bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleExecuteImport}
              disabled={parsedRows.length === 0 || parsedRows.filter(r => r.isValid).length === 0}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:pointer-events-none text-white rounded-lg text-xs font-bold font-mono transition-shadow shadow-md shadow-indigo-500/20 cursor-pointer"
            >
              Launch Bulk Import
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
