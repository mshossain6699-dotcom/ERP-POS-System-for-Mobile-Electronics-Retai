/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Bell,
  Clock,
  CheckCircle,
  HelpCircle,
  Calendar,
  Sparkles,
  Smartphone,
  Wallet,
  Coins
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TabName } from './Sidebar';

interface TopbarProps {
  currentTab: TabName;
}

export const Topbar: React.FC<TopbarProps> = ({ currentTab }) => {
  const { notifications, markNotificationRead, clearNotifications, accounts, settings } = useApp();
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);

  const getPageTitle = (tab: TabName) => {
    switch (tab) {
      case 'dashboard':
        return 'Executive Command Dashboard';
      case 'pos':
        return 'Point Of Sale (POS) Terminal';
      case 'products':
        return 'Device Catalog & Inventory';
      case 'imeis':
        return 'IMEI Serial Registry & Tracking';
      case 'sales':
        return 'Sales Archives & Invoicing';
      case 'purchases':
        return 'Vendor Stock Purchases';
      case 'contacts':
        return 'Counterparty CRM Directory';
      case 'accounts':
        return 'Financial Accounts & Ledgers';
      case 'expenses':
        return 'Shop Expenses & Charges';
      case 'coupons':
        return 'Promotion Coupons Management';
      case 'stock-adjustment':
        return 'Inventory Audits & Adjustments';
      case 'partners':
        return 'Equity Partners Ledger';
      case 'reports':
        return 'Strategic Analytics & Income Reports';
      case 'settings':
        return 'ERP Configurations & Controls';
      default:
        return 'Corporate ERP Portal';
    }
  };

  const unreadNotifications = notifications.filter((n) => !n.read);

  // Quick MFS wallets summary
  const bkashAcc = accounts.find((a) => a.name.toLowerCase().includes('bkash'));
  const nagadAcc = accounts.find((a) => a.name.toLowerCase().includes('nagad'));
  const cashAcc = accounts.find((a) => a.name.toLowerCase().includes('cash'));

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 h-16 px-6 flex items-center justify-between sticky top-0 z-40">
      {/* Title block */}
      <div className="flex flex-col">
        <h1 className="text-lg font-bold text-slate-100 tracking-tight leading-tight flex items-center gap-2">
          {getPageTitle(currentTab)}
        </h1>
        <div className="text-[10px] text-slate-400 font-medium flex items-center gap-1.5 md:flex">
          <span>Enterprise Portal</span>
          <span>•</span>
          <span className="text-indigo-400 font-semibold">{settings.shopName}</span>
        </div>
      </div>

      {/* Right widgets */}
      <div className="flex items-center gap-4">
        {/* Quick Wallet Indicators */}
        <div className="hidden lg:flex items-center gap-3">
          {bkashAcc && (
            <div className="bg-slate-950/60 border border-pink-500/30 px-3 py-1 rounded-full flex items-center gap-1.5 text-xs">
              <span className="w-2 h-2 rounded-full bg-pink-500 shadow-sm animate-pulse"></span>
              <span className="text-slate-400">bKash:</span>
              <span className="font-bold text-pink-400 font-mono">
                {settings.currency}
                {(bkashAcc.balance ?? 0).toLocaleString()}
              </span>
            </div>
          )}
          {nagadAcc && (
            <div className="bg-slate-950/60 border border-orange-500/30 px-3 py-1 rounded-full flex items-center gap-1.5 text-xs">
              <span className="w-2 h-2 rounded-full bg-orange-500 shadow-sm animate-pulse"></span>
              <span className="text-slate-400">Nagad:</span>
              <span className="font-bold text-orange-400 font-mono">
                {settings.currency}
                {(nagadAcc.balance ?? 0).toLocaleString()}
              </span>
            </div>
          )}
          {cashAcc && (
            <div className="bg-slate-950/60 border border-emerald-500/30 px-3 py-1 rounded-full flex items-center gap-1.5 text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-sm animate-pulse"></span>
              <span className="text-slate-400">Cash:</span>
              <span className="font-bold text-emerald-400 font-mono">
                {settings.currency}
                {(cashAcc.balance ?? 0).toLocaleString()}
              </span>
            </div>
          )}
        </div>

        {/* Live Clock */}
        <div className="bg-slate-800/60 px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs font-semibold text-slate-300 border border-slate-700/60">
          <Clock size={14} className="text-indigo-400" />
          <span className="font-mono">
            {new Date().toLocaleDateString('en-GB', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
            })}
          </span>
        </div>

        {/* Notifications component */}
        <div className="relative">
          <button
            onClick={() => setShowNotifDropdown(!showNotifDropdown)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition-colors relative border border-slate-700/60"
            title="System alerts"
          >
            <Bell size={16} />
            {unreadNotifications.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white font-mono font-bold text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center border border-slate-900 shadow-sm">
                {unreadNotifications.length}
              </span>
            )}
          </button>

          {/* Dropdown panel */}
          {showNotifDropdown && (
            <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-800 rounded-xl shadow-xl shadow-slate-950/40 py-2 z-50 text-slate-200">
              <div className="px-4 py-2 border-b border-slate-850 flex items-center justify-between">
                <span className="font-bold text-sm">System Alerts ({unreadNotifications.length})</span>
                {unreadNotifications.length > 0 && (
                  <button
                    onClick={() => {
                      clearNotifications();
                      setShowNotifDropdown(false);
                    }}
                    className="text-[11px] text-indigo-400 hover:text-indigo-300 font-bold"
                  >
                    Mark all read
                  </button>
                )}
              </div>
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/50">
                {notifications.length === 0 ? (
                  <div className="px-4 py-6 text-center text-xs text-slate-400">
                    No active notifications
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => markNotificationRead(n.id)}
                      className={`p-3 text-xs transition-colors cursor-pointer ${
                        n.read ? 'hover:bg-slate-800/40 opacity-75' : 'bg-slate-850 hover:bg-slate-800 font-medium'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2 mb-1">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider shrink-0 ${
                            n.type === 'LowStock'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/35'
                              : n.type === 'Target'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/35'
                              : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/35'
                          }`}
                        >
                          {n.type}
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono">{n.date}</span>
                      </div>
                      <p className="text-slate-300 leading-normal">{n.message}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
