/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Smartphone,
  Receipt,
  Download,
  Users,
  Wallet,
  ReceiptCent,
  Barcode,
  Ticket,
  Percent,
  TrendingUp,
  Settings,
  ChevronLeft,
  ChevronRight,
  Handshake,
  Workflow
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export type TabName =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'sales'
  | 'purchases'
  | 'contacts'
  | 'accounts'
  | 'expenses'
  | 'imeis'
  | 'coupons'
  | 'stock-adjustment'
  | 'partners'
  | 'reports'
  | 'settings';

interface SidebarProps {
  currentTab: TabName;
  onTabChange: (tab: TabName) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  collapsed,
  setCollapsed,
}) => {
  const { settings } = useApp();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, color: 'text-emerald-400' },
    { id: 'pos', label: 'POS Terminal', icon: ShoppingCart, color: 'text-blue-400' },
    { id: 'products', label: 'Device Inventory', icon: Smartphone, color: 'text-purple-400' },
    { id: 'imeis', label: 'IMEI Tracking', icon: Barcode, color: 'text-amber-400' },
    { id: 'sales', label: 'Sales History', icon: Receipt, color: 'text-teal-400' },
    { id: 'purchases', label: 'Stock Purchases', icon: Download, color: 'text-indigo-400' },
    { id: 'contacts', label: 'Contacts Directory', icon: Users, color: 'text-sky-400' },
    { id: 'accounts', label: 'Financial Accounts', icon: Wallet, color: 'text-pink-400' },
    { id: 'expenses', label: 'Shop Expenses', icon: ReceiptCent, color: 'text-red-400' },
    { id: 'coupons', label: 'Promo Coupons', icon: Ticket, color: 'text-orange-400' },
    { id: 'stock-adjustment', label: 'Stock Adjustments', icon: Workflow, color: 'text-cyan-400' },
    { id: 'partners', label: 'Partner Capital', icon: Handshake, color: 'text-yellow-400' },
    { id: 'reports', label: 'Business Reports', icon: TrendingUp, color: 'text-rose-400' },
    { id: 'settings', label: 'ERP Settings', icon: Settings, color: 'text-slate-400' },
  ] as const;

  return (
    <aside
      className={`bg-slate-900 border-r border-slate-800 flex flex-col justify-between transition-all duration-300 h-screen sticky top-0 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div>
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center gap-2 overflow-hidden">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white text-base shadow-lg shadow-blue-500/20 shrink-0">
                M
              </div>
              <div className="flex flex-col">
                <span className="text-white font-bold text-sm truncate tracking-tight leading-tight">
                  {settings.shopName || 'MobiERP Pro'}
                </span>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-none">
                  Uttara Main
                </span>
              </div>
            </div>
          )}
          {collapsed && (
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white text-base shadow-lg shadow-blue-500/20 mx-auto">
              M
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden md:flex p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>

        {/* Navigation links */}
        <nav className="p-2 space-y-1 overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-thin scrollbar-thumb-slate-800">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                  isActive
                    ? 'bg-white/10 text-white shadow-md border-r-4 border-blue-500 rounded-r-none'
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                }`}
                title={item.label}
              >
                <Icon
                  size={18}
                  className={`shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-blue-500' : item.color
                  }`}
                />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      {/* User Session Info footer */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/40">
        <div className="flex items-center gap-2 overflow-hidden">
          <div className="w-8 h-8 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center font-semibold text-xs text-white shrink-0 uppercase">
            ZH
          </div>
          {!collapsed && (
            <div className="flex flex-col overflow-hidden">
              <span className="text-xs font-bold text-slate-200 truncate leading-tight">
                Zahid Hasan
              </span>
              <span className="text-[9px] text-amber-500 font-semibold uppercase tracking-wide">
                CEO / Owner
              </span>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
