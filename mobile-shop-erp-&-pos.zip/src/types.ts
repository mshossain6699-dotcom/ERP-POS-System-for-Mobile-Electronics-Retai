/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  model: string;
  brand: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  quantity: number;
  imeis: string[]; // List of available IMEI numbers if this product is phone
  color: string;
  ram: string;
  storage: string;
  isPhone: boolean; // True of FALSE (General accessories)
  lowStockLimit: number;
  status: 'In Stock' | 'Out of Stock' | 'Low Stock';
}

export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface Brand {
  id: string;
  name: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  totalSpent: number;
  dueBalance: number;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  email?: string;
  company: string;
  dueBalance: number;
}

export interface SaleItem {
  productId: string;
  productName: string;
  model: string;
  price: number;
  quantity: number;
  discount: number; // Flat discount per item
  imeis: string[];  // Selected IMEIs for this sale
  isPhone: boolean;
}

export type PaymentMethod = 'Cash' | 'bKash' | 'Nagad' | 'Rocket' | 'Card' | 'Bank';

export interface Sale {
  id: string;
  invoiceNo: string;
  date: string; // ISO String or YYYY-MM-DD
  customerId: string;
  customerName: string;
  customerPhone: string;
  items: SaleItem[];
  subtotal: number;
  couponCode?: string;
  couponDiscount: number;
  taxAmount: number;
  total: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  costPrice: number;
  quantity: number;
  imeis: string[];
}

export interface Purchase {
  id: string;
  date: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseItem[];
  total: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: string;
  notes?: string;
}

export interface Expense {
  id: string;
  date: string;
  description: string;
  category: string;
  amount: number;
  paymentAccount: string; // e.g. "Cash Account", "Bank Account"
}

export interface Account {
  id: string;
  name: string;
  type: 'Cash' | 'MFS' | 'Bank';
  accountNo?: string;
  balance: number;
}

export interface Transaction {
  id: string;
  date: string;
  accountId: string;
  type: 'Deposit' | 'Withdrawal' | 'Tfr Out' | 'Tfr In' | 'Income' | 'Expense' | 'Sale' | 'Purchase';
  amount: number;
  description: string;
  refId?: string; // Associated invoice / purchase / expense ID
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'Flat' | 'Percentage';
  discountValue: number;
  minPurchase: number;
  expiryDate: string;
  isActive: boolean;
}

export interface Partner {
  id: string;
  name: string;
  sharePercentage: number;
  capitalContributed: number;
  balanceDrawing: number;
}

export interface StockAdjustment {
  id: string;
  date: string;
  productId: string;
  productName: string;
  type: 'Addition' | 'Subtraction';
  quantity: number;
  reason: string;
  adjustedBy: string;
}

export interface Notification {
  id: string;
  date: string;
  message: string;
  type: 'LowStock' | 'System' | 'Target' | 'Alert';
  read: boolean;
}

export interface ShopSettings {
  shopName: string;
  address: string;
  contactNo: string;
  currency: string;
  vatPercent: number;
  invoiceFooter: string;
  bkashMerchantNo: string;
  nagadMerchantNo: string;
  rocketNo: string;
  targetMonthlySales: number;
}
