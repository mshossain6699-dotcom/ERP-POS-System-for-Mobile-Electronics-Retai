/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Landmark, Plus, Search, Handshake, DollarSign, PiggyBank, Briefcase, HelpCircle, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Partners: React.FC = () => {
  const { partners, updatePartnerCapital, settings } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [selectedPartnerId, setSelectedPartnerId] = useState(partners[0]?.id || '');
  const [opType, setOpType] = useState<'Investment' | 'Drawing'>('Investment');
  const [amt, setAmt] = useState(0);
  const [memo, setMemo] = useState('');

  const totalCapitalInPlay = partners.reduce((sum, p) => sum + p.capital, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPartnerId) {
      alert('Must select a specific equity partner.');
      return;
    }
    if (amt <= 0) {
      alert('Investment/drawing value must exceed 0.');
      return;
    }

    const success = updatePartnerCapital(selectedPartnerId, opType, amt);
    if (!success) {
      alert('Unsuccessful: Drawings value exceeds current capital balance of the target shareholder.');
      return;
    }

    setIsModalOpen(false);
    setAmt(0);
    setMemo('');
    alert(`Shareholder action logged. Capital pool settled.`);
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Header widget box */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-xl text-teal-400">
            <Handshake size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Partners Equity Shareholdings</h2>
            <p className="text-[11px] text-slate-400">Track venture capital injections, drawing accounts and equity profit shares splits</p>
          </div>
        </div>

        <button
          onClick={() => {
            setIsModalOpen(true);
            setSelectedPartnerId(partners[0]?.id || '');
          }}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
        >
          <Plus size={15} />
          <span>Record Capital Settle</span>
        </button>
      </div>

      {/* 2. Consolidated Capital summary row cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center gap-3.5">
          <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400">
            <PiggyBank size={18} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Aggregate Capital Invested</span>
            <strong className="text-sm text-slate-100 font-mono font-bold leading-tight">
              ৳{totalCapitalInPlay.toLocaleString()}
            </strong>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center gap-3.5">
          <div className="p-3 bg-teal-500/10 rounded-xl text-teal-400">
            <Briefcase size={18} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Strategic Shareholders</span>
            <strong className="text-sm text-slate-100 font-bold leading-tight">
              {partners.length} Active venture partners
            </strong>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center gap-3.5">
          <div className="p-3 bg-amber-500/10 rounded-xl text-amber-500">
            <DollarSign size={18} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Legal Entity Type</span>
            <strong className="text-sm text-slate-100 font-bold uppercase tracking-wider text-[11px] leading-tight">
              Partnership Association (LLP)
            </strong>
          </div>
        </div>
      </div>

      {/* 3. Partners holdings directories list */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/15">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-405 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Partner Name / ID</th>
                <th className="py-3 px-4">Co-Founding Credentials Role</th>
                <th className="py-3 px-4 text-right">Investment Venture Capital</th>
                <th className="py-3 px-4 text-center">Calculated Equity Split %</th>
                <th className="py-3 px-4">Associated Registry Contact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {partners.map((p) => {
                const percentage = totalCapitalInPlay > 0 ? (p.capital / totalCapitalInPlay) * 100 : 0;
                
                return (
                  <tr key={p.id} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-4 px-4 font-bold text-slate-105 text-slate-100 flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-teal-400"></div>
                      <span>{p.name}</span>
                    </td>
                    <td className="py-4 px-4 font-semibold text-slate-400">{p.role}</td>
                    <td className="py-4 px-4 text-right font-mono font-extrabold text-slate-100 text-sm">
                      ৳{p.capital.toLocaleString()}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className="bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-extrabold text-[10px] font-mono px-2 py-0.5 rounded-full">
                        {percentage.toFixed(1)}% Shares
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-450 font-mono text-[10px]">{p.phone || 'N/A'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* EQUITY PARTNER ACTION DIALOG MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 pb-2 border-b border-slate-850">
              <Handshake size={16} className="text-teal-400" />
              <span>Record Shareholders Ledger</span>
            </h4>

            <div className="space-y-3.5">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Venture Shareholder</label>
                <select
                  value={selectedPartnerId}
                  onChange={(e) => setSelectedPartnerId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                >
                  {partners.map(p => (
                    <option key={p.id} value={p.id} className="bg-slate-900">{p.name} ({p.role})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Shifting Ledger Action</label>
                <select
                  value={opType}
                  onChange={(e) => setOpType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                >
                  <option value="Investment">New Capital Investment (+)</option>
                  <option value="Drawing">Shareholder Profit Drawing (-)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Capital Value sum (BDT)</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 50000"
                  value={amt || ''}
                  onChange={(e) => setAmt(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-mono font-bold focus:outline-none text-teal-400"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Transaction audit Trail Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Phase 2 showroom expansion capital, drawings..."
                  value={memo}
                  onChange={(e) => setMemo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 border border-slate-800 text-slate-300 rounded-lg text-xs font-bold"
              >
                Discard
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold font-mono shadow-md"
              >
                Commit Journal
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
