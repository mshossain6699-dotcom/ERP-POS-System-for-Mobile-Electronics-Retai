/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Users, UserPlus, ShieldAlert, CheckCircle, Smartphone, AlertTriangle, Mail, MapPin, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Customer, Supplier } from '../types';

export const Contacts: React.FC = () => {
  const {
    customers,
    suppliers,
    addCustomer,
    updateCustomer,
    addSupplier,
    updateSupplier,
    settings
  } = useApp();

  const [activeTab, setActiveTab] = useState<'customers' | 'suppliers'>('customers');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    company: '' // supplier only
  });

  // Open Add Modal
  const openAddModal = () => {
    setEditingId(null);
    setForm({ name: '', phone: '', email: '', address: '', company: '' });
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const openEditModal = (obj: any) => {
    setEditingId(obj.id);
    setForm({
      name: obj.name,
      phone: obj.phone,
      email: obj.email || '',
      address: obj.address || '',
      company: obj.company || ''
    });
    setIsModalOpen(true);
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Submit Counterparty CRM entry
  const handleSubmitCounterparty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      alert('Name & core Phone details must be fulfilled.');
      return;
    }

    if (activeTab === 'customers') {
      if (editingId) {
        const exist = customers.find(c => c.id === editingId)!;
        updateCustomer({ ...exist, ...form });
        alert('Customer file updated.');
      } else {
        addCustomer(form);
        alert('Customer CRM record created.');
      }
    } else {
      if (editingId) {
        const exist = suppliers.find(s => s.id === editingId)!;
        updateSupplier({ ...exist, ...form, company: form.company.trim() || 'Direct Agent' });
        alert('Supplier credentials updated.');
      } else {
        addSupplier({ ...form, company: form.company.trim() || 'Direct Distribution' });
        alert('Supplier credentials submitted to catalog.');
      }
    }

    setIsModalOpen(false);
  };

  const filteredCustomers = customers.filter(c => {
    const term = searchTerm.toLowerCase();
    return c.name.toLowerCase().includes(term) || c.phone.includes(term) || (c.email && c.email.toLowerCase().includes(term));
  });

  const filteredSuppliers = suppliers.filter(s => {
    const term = searchTerm.toLowerCase();
    return s.name.toLowerCase().includes(term) || s.phone.includes(term) || s.company.toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      
      {/* KPI info card row */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
            <Users size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Counterparties CRM Directory</h2>
            <p className="text-[11px] text-slate-400">Database profiling clients, frequent buyers, partners and wholesale suppliers</p>
          </div>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
        >
          <UserPlus size={15} />
          <span>Register Counterparty</span>
        </button>
      </div>

      {/* Switch tabs menu */}
      <div className="border-b border-slate-800 flex">
        <button
          onClick={() => { setActiveTab('customers'); setSearchTerm(''); }}
          className={`px-5 py-3 text-xs font-bold border-b-2 hover:text-slate-100 transition-colors ${
            activeTab === 'customers' ? 'border-indigo-500 text-indigo-400 bg-slate-900/40' : 'border-transparent text-slate-400'
          }`}
        >
          Customers CRM ({customers.length})
        </button>
        <button
          onClick={() => { setActiveTab('suppliers'); setSearchTerm(''); }}
          className={`px-5 py-3 text-xs font-bold border-b-2 hover:text-slate-100 transition-colors ${
            activeTab === 'suppliers' ? 'border-indigo-500 text-indigo-400 bg-slate-900/40' : 'border-transparent text-slate-400'
          }`}
        >
          Sourcing Suppliers ({suppliers.length})
        </button>
      </div>

      {/* Search line controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder={activeTab === 'customers' ? 'Search customer phone, buyer tag...' : 'Search supplier company, name, contact...'}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Render Table grids */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/10">
        <div className="overflow-x-auto">
          {activeTab === 'customers' ? (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-950 text-slate-450 font-bold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Customer Name / ID</th>
                  <th className="py-3 px-4">Linked Mobile Contact</th>
                  <th className="py-3 px-4">Contact Coordinates</th>
                  <th className="py-3 px-4 text-right">Aggregate Spent Sum</th>
                  <th className="py-3 px-4 text-right">Outstanding Dues</th>
                  <th className="py-3 px-4 text-center">Counter Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filteredCustomers.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-3 px-4 font-bold text-slate-100">
                      {c.name}
                      <span className="block text-[9px] text-slate-400 font-normal font-mono mt-0.5">CRM-ID: {c.id}</span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-350">{c.phone}</td>
                    <td className="py-3 px-4 text-slate-450">
                      <span className="flex items-center gap-1"><Mail size={12} className="text-slate-550" /> {c.email || 'N/A'}</span>
                      <span className="flex items-center gap-1 mt-0.5"><MapPin size={12} className="text-slate-550" /> {c.address || 'N/A'}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-100">
                      {settings.currency}
                      {c.totalSpent.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-rose-450 text-rose-400">
                      {settings.currency}
                      {c.dueBalance.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => openEditModal(c)}
                        className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-750 transition-colors cursor-pointer"
                      >
                        Modify
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-950 text-slate-450 font-bold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Supplier Name / ID</th>
                  <th className="py-3 px-4">Sourcing Company / Agency</th>
                  <th className="py-3 px-4 font-normal">Registered Mobile</th>
                  <th className="py-3 px-4">Contact Details</th>
                  <th className="py-3 px-4 text-right">Outstanding Bills Due</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filteredSuppliers.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-3 px-4 font-bold text-slate-100">
                      {s.name}
                      <span className="block text-[9px] text-slate-400 font-normal font-mono mt-0.5">SUP-ID: {s.id}</span>
                    </td>
                    <td className="py-3 px-4 font-bold text-indigo-400">{s.company}</td>
                    <td className="py-3 px-4 font-mono font-semibold">{s.phone}</td>
                    <td className="py-3 px-4 text-slate-450">
                      <span className="flex items-center gap-1"><Mail size={12} className="text-slate-550" /> {s.email || 'N/A'}</span>
                      <span className="flex items-center gap-1 mt-0.5"><MapPin size={12} className="text-slate-550" /> {s.address || 'N/A'}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-rose-400">
                      {settings.currency}
                      {s.dueBalance.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => openEditModal(s)}
                        className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-750 transition-colors cursor-pointer"
                      >
                        Modify
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* NEW/EDIT MODAL PORT */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <form onSubmit={handleSubmitCounterparty} className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 pb-2 border-b border-slate-850">
              <UserPlus size={16} className="text-indigo-400" />
              <span>{editingId ? 'Modify credentials' : `Lodge New ${activeTab === 'customers' ? 'Customer CRM' : 'Sourcing Vendor'}`}</span>
            </h4>

            <div className="space-y-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Company / Sourcing Merchant (Suppliers Only)</label>
                <input
                  type="text"
                  name="company"
                  disabled={activeTab === 'customers'}
                  placeholder="e.g. Dhaka Mobile Wholesales"
                  value={form.company}
                  onChange={handleFormChange}
                  className="w-full bg-slate-950 disabled:opacity-30 disabled:pointer-events-none border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Full Representative Person Name</label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. Shakil Ahmed"
                  value={form.name}
                  onChange={handleFormChange}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Mobile Contact Phone</label>
                <input
                  type="text"
                  name="phone"
                  required
                  placeholder="e.g. 017XXXXXXXX"
                  value={form.phone}
                  onChange={handleFormChange}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Email Coordinates</label>
                <input
                  type="email"
                  name="email"
                  placeholder="e.g. contact@domain.com"
                  value={form.email}
                  onChange={handleFormChange}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Hometown Address / Logistics Hub</label>
                <input
                  type="text"
                  name="address"
                  placeholder="e.g. Uttara Ward 5, Dhaka"
                  value={form.address}
                  onChange={handleFormChange}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 border border-slate-800 text-slate-300 rounded-lg text-xs font-bold"
              >
                Discard
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
              >
                Lodge Credentials
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
