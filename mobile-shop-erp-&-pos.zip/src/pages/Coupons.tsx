/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Ticket, Plus, Search, HelpCircle, CheckCircle, AlertOctagon, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Coupons: React.FC = () => {
  const { coupons, addCoupon, toggleCouponActive, settings } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form states
  const [code, setCode] = useState('');
  const [type, setType] = useState<'Flat' | 'Percentage'>('Flat');
  const [val, setVal] = useState(0);
  const [min, setMin] = useState(0);
  const [expiry, setExpiry] = useState('2026-12-31');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      alert('Coupon code cannot remain empty.');
      return;
    }
    if (val <= 0) {
      alert('Discount value must exceed 0.');
      return;
    }

    addCoupon({
      code: code.trim().toUpperCase(),
      discountType: type,
      discountValue: val,
      minPurchase: min,
      expiryDate: expiry,
      isActive: true
    });

    setIsModalOpen(false);
    setCode('');
    setVal(0);
    setMin(0);
    alert('Coupon code campaign launched successfully.');
  };

  const filteredCoupons = coupons.filter(c => {
    return c.code.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-6">
      
      {/* 1. Header widget */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-orange-500/10 border border-orange-500/20 rounded-xl text-orange-450 text-orange-400">
            <Ticket size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">POS Marketing Coupon Campaign</h2>
            <p className="text-[11px] text-slate-400">Configure discount code triggers to boost shopping cart size at sales counter</p>
          </div>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
        >
          <Plus size={15} />
          <span>Launch Promo Campaign</span>
        </button>
      </div>

      {/* 2. Search controllers */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder="Search coupon code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none placeholder:normal-case font-mono focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Grid Table list */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/15">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-405 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Coupon Campaign Code</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4 text-right font-normal">Discount Rate</th>
                <th className="py-3 px-4 text-right">Min Cart Val Threshold</th>
                <th className="py-3 px-4 text-center">Expiry Target</th>
                <th className="py-3 px-4 text-center">Deployment status</th>
                <th className="py-3 px-4 text-center">Actions Trigger</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredCoupons.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/15 text-slate-300">
                  <td className="py-3 px-4 font-mono font-extrabold text-indigo-400 select-all tracking-wide text-xs">{c.code}</td>
                  <td className="py-3 px-4 font-semibold text-slate-400">{c.discountType} Discount</td>
                  <td className="py-3 px-4 text-right font-mono font-extrabold text-slate-200 text-sm">
                    {c.discountType === 'Flat' ? `৳${c.discountValue.toLocaleString()}` : `${c.discountValue}%`}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-indigo-400">
                    ৳{c.minPurchase.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-slate-400">{c.expiryDate}</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      c.isActive ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-505/20' : 'bg-slate-800 text-slate-500 border border-slate-850'
                    }`}>
                      {c.isActive ? 'Active and deployed' : 'Deactivated / Deployed'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => toggleCouponActive(c.id)}
                      className={`px-3 py-1 rounded text-[11px] font-bold transition-colors cursor-pointer ${
                        c.isActive ? 'bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/20' : 'bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white border border-indigo-500/20'
                      }`}
                    >
                      {c.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
              {filteredCoupons.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No promo coupons campaigns logged in sales database directories.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* DUMP CAMPAIGN MODAL CARD */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 pb-2 border-b border-slate-850">
              <Ticket size={16} className="text-orange-450 text-orange-400" />
              <span>Configure Promo Coupon Campaign</span>
            </h4>

            <div className="space-y-3.5">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Coupon code tag identifier</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. EIDBATCH26"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none uppercase font-mono font-bold tracking-wide"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Discount Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none font-bold"
                  >
                    <option value="Flat">Flat Cash Rate (৳)</option>
                    <option value="Percentage">Percentage Split (%)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Discount Value</label>
                  <input
                    type="number"
                    required
                    placeholder="e.g. 500"
                    value={val || ''}
                    onChange={(e) => setVal(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-mono font-bold focus:outline-none text-indigo-400"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Minimum Cart Purchase required (৳)</label>
                <input
                  type="number"
                  placeholder="e.g. 1000"
                  value={min || ''}
                  onChange={(e) => setMin(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-mono font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Campaign expiry target</label>
                <input
                  type="date"
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 border border-slate-800 text-slate-300 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold font-mono shadow-md"
              >
                Launch Coupon Link
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
