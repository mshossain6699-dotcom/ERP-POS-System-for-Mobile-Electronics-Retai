/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Search,
  ShoppingCart,
  Trash2,
  UserPlus,
  Ticket,
  DollarSign,
  QrCode,
  Smartphone,
  Plus,
  Minus,
  Check,
  AlertCircle,
  FileText,
  Printer,
  ChevronRight,
  Sparkles,
  Percent,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product, Customer, PaymentMethod, SaleItem } from '../types';

interface CartItem {
  product: Product;
  quantity: number;
  discount: number; // custom discount BDT per item
  selectedImeis: string[]; // selected IMEIs if isPhone
}

export const POS: React.FC = () => {
  const {
    products,
    customers,
    addCustomer,
    coupons,
    accounts,
    addSale,
    settings
  } = useApp();

  // Left inventory list states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');
  const [imeiQuery, setImeiQuery] = useState('');

  // Cart states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState('CUST-WALK');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<typeof coupons[0] | null>(null);
  
  // Custom discounts or override total
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod>('Cash');
  const [notes, setNotes] = useState('');

  // Modals / Drawer displays
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [imeiSelectionProduct, setImeiSelectionProduct] = useState<Product | null>(null);
  const [tempImeis, setTempImeis] = useState<string[]>([]);
  const [invoicePreviewSale, setInvoicePreviewSale] = useState<any | null>(null);

  // New customer quick-add fields
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');

  // Quick select category list
  const categoryList = ['All', 'Smartphones', 'Feature Phones', 'Accessories'];

  // --- AUTOMATIC SCALABLE CALCULATIONS ---
  const cartSubtotal = cart.reduce((sum, item) => {
    const itemTotal = (item.product.sellingPrice - item.discount) * item.quantity;
    return sum + itemTotal;
  }, 0);

  const couponDiscountAmount = (() => {
    if (!appliedCoupon || cartSubtotal < appliedCoupon.minPurchase) return 0;
    if (appliedCoupon.discountType === 'Flat') return appliedCoupon.discountValue;
    return Math.round((cartSubtotal * appliedCoupon.discountValue) / 100);
  })();

  const subtotalWithCoupons = Math.max(0, cartSubtotal - couponDiscountAmount);
  const taxAmount = Math.round((subtotalWithCoupons * settings.vatPercent) / 100);
  const cartTotal = subtotalWithCoupons + taxAmount;
  const dueAmount = Math.max(0, cartTotal - paidAmount);

  // Default paid amount setter as total changes
  useEffect(() => {
    setPaidAmount(cartTotal);
  }, [cartTotal]);

  // IMEI quick lookup bar check (Scan trigger simulating barcode entry)
  useEffect(() => {
    if (imeiQuery.trim().length >= 5) {
      // Find matching item containing this IMEI
      const matchedProd = products.find(p => p.isPhone && p.imeis.includes(imeiQuery.trim()));
      if (matchedProd) {
        // Trigger adding to cart automatically with this IMEI pre-selected
        addOrUpdateCartWithIMEI(matchedProd, imeiQuery.trim());
        setImeiQuery('');
        alert(`IMEI lookup success! Added ${matchedProd.name} to cart.`);
      }
    }
  }, [imeiQuery]);

  // Add Item to cart logic
  const handleItemClick = (p: Product) => {
    if (p.quantity <= 0) {
      alert('This device product is currently fully out of stock!');
      return;
    }

    if (p.isPhone) {
      // Must open modal to select which specific IMEI serial is sold
      setImeiSelectionProduct(p);
      setTempImeis([]);
    } else {
      // Check if already in cart
      const existing = cart.find(item => item.product.id === p.id);
      if (existing) {
        if (existing.quantity >= p.quantity) {
          alert(`Insufficient physical reserves. Maximum stock is ${p.quantity}.`);
          return;
        }
        setCart(prev => prev.map(item =>
          item.product.id === p.id ? { ...item, quantity: item.quantity + 1 } : item
        ));
      } else {
        setCart(prev => [...prev, { product: p, quantity: 1, discount: 0, selectedImeis: [] }]);
      }
    }
  };

  // Dedicated IMEI selection apply handler
  const handleApplyIMEIs = () => {
    if (!imeiSelectionProduct) return;
    if (tempImeis.length === 0) {
      alert('You must choose at least 1 IMEI code to proceed selling a phone.');
      return;
    }

    // Add or replace phone in cart
    const existing = cart.find(item => item.product.id === imeiSelectionProduct.id);
    if (existing) {
      setCart(prev => prev.map(item =>
        item.product.id === imeiSelectionProduct.id
          ? { ...item, quantity: tempImeis.length, selectedImeis: tempImeis }
          : item
      ));
    } else {
      setCart(prev => [...prev, {
        product: imeiSelectionProduct,
        quantity: tempImeis.length,
        discount: 0,
        selectedImeis: tempImeis
      }]);
    }

    setImeiSelectionProduct(null);
    setTempImeis([]);
  };

  // Support automated IMEI scanning barcodes
  const addOrUpdateCartWithIMEI = (prod: Product, targetImei: string) => {
    const existing = cart.find(item => item.product.id === prod.id);
    if (existing) {
      if (existing.selectedImeis.includes(targetImei)) return; // already there
      const nextImeis = [...existing.selectedImeis, targetImei];
      setCart(prev => prev.map(item =>
        item.product.id === prod.id ? { ...item, quantity: nextImeis.length, selectedImeis: nextImeis } : item
      ));
    } else {
      setCart(prev => [...prev, {
        product: prod,
        quantity: 1,
        discount: 0,
        selectedImeis: [targetImei]
      }]);
    }
  };

  const handleRemoveItem = (id: string) => {
    setCart(prev => prev.filter(item => item.product.id !== id));
  };

  const updateCartQty = (id: string, newQty: number) => {
    const item = cart.find(x => x.product.id === id);
    if (!item) return;

    if (newQty <= 0) {
      handleRemoveItem(id);
      return;
    }

    if (item.product.isPhone) {
      alert('For mobile devices, stock quantity is derived strictly by selecting specific IMEI codes.');
      return;
    }

    if (newQty > item.product.quantity) {
      alert(`Limit exceeded. Only ${item.product.quantity} items left in stock.`);
      return;
    }

    setCart(prev => prev.map(x => x.product.id === id ? { ...x, quantity: newQty } : x));
  };

  const updateCartItemDiscount = (id: string, discValue: number) => {
    setCart(prev => prev.map(x => x.product.id === id ? { ...x, discount: Math.max(0, discValue) } : x));
  };

  // Promo Coupon application validator
  const handleValidateCoupon = () => {
    const match = coupons.find(c => c.code.toLowerCase() === couponCode.trim().toLowerCase());
    if (!match) {
      alert('Invalid code. Coupon not recognized in system registry.');
      setAppliedCoupon(null);
      return;
    }
    if (!match.isActive) {
      alert('This coupon is currently deactivated / expired.');
      setAppliedCoupon(null);
      return;
    }
    if (cartSubtotal < match.minPurchase) {
      alert(`Min. cart purchase for this coupon is ৳${match.minPurchase.toLocaleString()}`);
      setAppliedCoupon(null);
      return;
    }
    setAppliedCoupon(match);
  };

  // Reset pos states
  const handleResetPOS = () => {
    setCart([]);
    setSelectedCustomerId('CUST-WALK');
    setCouponCode('');
    setAppliedCoupon(null);
    setPaidAmount(0);
    setSelectedPaymentMethod('Cash');
    setNotes('');
  };

  // Submit Sale Complete Action
  const handleCompletePaymentSale = () => {
    if (cart.length === 0) {
      alert('Cannot checkout an empty POS billing cart.');
      return;
    }

    const customerObj = customers.find(c => c.id === selectedCustomerId) || customers[0];

    // Build invoice record payload
    const saleItemsList: SaleItem[] = cart.map(c => ({
      productId: c.product.id,
      productName: c.product.name,
      model: c.product.model,
      price: c.product.sellingPrice,
      quantity: c.quantity,
      discount: c.discount,
      imeis: c.selectedImeis,
      isPhone: c.product.isPhone
    }));

    // Find actual financial account connected to this payment type
    // If Cash selected, match CASH Account name, bKash with bKash, BRAC bank with Bank etc.
    let mappedAccountName = 'Cash Register (Drawer)';
    if (selectedPaymentMethod === 'bKash') mappedAccountName = 'bKash Merchant Account';
    else if (selectedPaymentMethod === 'Nagad') mappedAccountName = 'Nagad Business Wallet';
    else if (selectedPaymentMethod === 'Bank' || selectedPaymentMethod === 'Card') mappedAccountName = 'BRAC Bank Business A/C';

    const salePayload = {
      date: new Date().toISOString().split('T')[0],
      customerId: selectedCustomerId,
      customerName: customerObj.name,
      customerPhone: customerObj.phone,
      items: saleItemsList,
      subtotal: cartSubtotal,
      couponCode: appliedCoupon ? appliedCoupon.code : undefined,
      couponDiscount: couponDiscountAmount,
      taxAmount,
      total: cartTotal,
      paidAmount,
      dueAmount,
      paymentMethod: mappedAccountName as any, // Context matches account Names
      notes
    };

    addSale(salePayload);
    
    // Store in temp local hook to open dynamic invoice print preview
    setInvoicePreviewSale({
      ...salePayload,
      invoiceNo: `INV-2026-${Math.floor(100 + Math.random() * 900)}`, // temporary simulated number until database ref
    });

    handleResetPOS();
  };

  // Add Dynamic quick customer
  const handleTriggerQuickCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim() || !newCustPhone.trim()) {
      alert('Verify customer name and core mobile numbers are valid.');
      return;
    }

    const created = addCustomer({
      name: newCustName.trim(),
      phone: newCustPhone.trim(),
      email: 'quickpos@shop.com',
      address: newCustAddress.trim() || 'Dhaka Counter CRM Regist',
    });

    setSelectedCustomerId(created.id);
    setIsCustomerModalOpen(false);
    setNewCustName('');
    setNewCustPhone('');
    setNewCustAddress('');
  };

  // Filtering Products on LEFT side catalog
  const leftFilteredProducts = products.filter(p => {
    const sTerm = searchTerm.toLowerCase();
    const matchSearch = p.name.toLowerCase().includes(sTerm) || p.model.toLowerCase().includes(sTerm) || p.id.toLowerCase().includes(sTerm);
    const matchCat = selectedCat === 'All' || p.category === selectedCat;
    return matchSearch && matchCat;
  });

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 h-[calc(100vh-100px)]">
      
      {/* LEFT SIDE: PRODUCT CATALOGS GRID (7/12 grid span) */}
      <div className="xl:col-span-7 flex flex-col justify-between space-y-4 h-full bg-slate-900 border border-slate-800 rounded-2xl p-5 overflow-hidden">
        
        {/* Top search & scanning fields */}
        <div className="space-y-3 shrink-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
              <input
                type="text"
                placeholder="Search accessories & device catalog..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="relative">
              <QrCode className="absolute left-3 top-2.5 text-indigo-400" size={15} />
              <input
                type="text"
                placeholder="Scan or type device IMEI barcode..."
                value={imeiQuery}
                onChange={(e) => setImeiQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-indigo-400 font-mono font-bold focus:outline-none focus:border-indigo-500 placeholder:text-slate-600 focus:ring-1 focus:ring-indigo-500/20"
              />
            </div>
          </div>

          {/* Quick Categories filter tabs bar */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 select-none scrollbar-none">
            {categoryList.map((cat, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedCat(cat)}
                className={`py-1.5 px-3.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCat === cat
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-850'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Catalog list container */}
        <div className="flex-1 overflow-y-auto pr-1 select-none scrollbar-thin scrollbar-thumb-slate-800">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {leftFilteredProducts.map((p) => {
              const isLow = p.status === 'Low Stock' || p.status === 'Out of Stock';
              
              return (
                <div
                  key={p.id}
                  onClick={() => handleItemClick(p)}
                  className={`bg-slate-950/40 hover:bg-slate-950/80 border rounded-xl p-3.5 flex flex-col justify-between gap-3 cursor-pointer transition-all active:scale-97 group shadow-sm ${
                    isLow ? 'border-amber-500/25' : 'border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex justify-between items-start gap-1">
                      <span className="text-[9px] font-bold tracking-wider uppercase text-indigo-400 bg-indigo-500/10 px-1 rounded">
                        {p.brand}
                      </span>
                      <span className={`text-[9px] font-bold px-1.5 rounded-full ${
                        p.quantity === 0
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/25'
                          : p.quantity <= p.lowStockLimit
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-505/15'
                      }`}>
                        {p.quantity} left
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-slate-200 line-clamp-2 leading-tight group-hover:text-indigo-400 transition-colors">
                      {p.name}
                    </h4>
                    
                    {p.isPhone && (
                      <span className="text-[9px] text-slate-500 font-bold block mt-0.5">
                        {p.ram}/{p.storage} • {p.color}
                      </span>
                    )}
                  </div>

                  <div className="flex justify-between items-center border-t border-slate-900 pt-2 shrink-0">
                    <span className="text-slate-400 text-[10px]">SRP Rate</span>
                    <span className="text-emerald-400 font-bold font-mono text-sm">
                      {settings.currency}
                      {(p.sellingPrice ?? 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
            {leftFilteredProducts.length === 0 && (
              <div className="col-span-full py-16 text-center text-xs text-slate-500">
                No inventory matches catalog lookup search keys.
              </div>
            )}
          </div>
        </div>

      </div>

      {/* RIGHT SIDE: POS CART, INVOICING & CHECKOUT (5/12 grid span) */}
      <div className="xl:col-span-5 flex flex-col justify-between h-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden p-5 shadow-xl">
        
        {/* CRM Customer selector line */}
        <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/80 flex items-center gap-2 mb-4 shrink-0">
          <div className="w-full flex items-center gap-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400">Client:</span>
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full bg-transparent text-xs text-slate-200 font-bold focus:outline-none cursor-pointer"
            >
              {customers.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-900 font-bold text-xs p-2">
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={() => setIsCustomerModalOpen(true)}
            className="p-1.5 bg-indigo-600/10 border border-indigo-500/25 rounded-lg text-indigo-400 hover:bg-indigo-600 hover:text-white transition-all cursor-pointer"
            title="Add customer on spot"
          >
            <UserPlus size={14} />
          </button>
        </div>

        {/* Invoice Item list cart */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-850 select-none pr-1 scrollbar-thin scrollbar-thumb-slate-800">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <ShoppingCart size={32} className="text-slate-700 mb-2" />
              <p className="text-xs font-bold text-slate-500">POS Billing Cart is Empty</p>
              <p className="text-[10px] text-slate-650 max-w-[200px] mt-1 leading-normal">Click items in device catalog left or scan barcodes to begin invoicing</p>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.product.id} className="py-3 text-xs flex flex-col gap-1.5">
                <div className="flex justify-between items-start gap-2">
                  <div className="max-w-[200px]">
                    <span className="font-bold text-slate-200">{item.product.name}</span>
                    <span className="block text-[9px] text-slate-400">{item.product.model}</span>
                    {item.selectedImeis.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {item.selectedImeis.map((imei, index) => (
                          <span key={index} className="bg-slate-950 border border-slate-800 text-indigo-400 font-mono text-[8px] px-1 rounded font-bold">
                            {imei}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => handleRemoveItem(item.product.id)}
                    className="p-1 rounded bg-slate-950 hover:bg-rose-950 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>

                {/* Adjustments row */}
                <div className="flex items-center justify-between mt-1 pt-1 border-t border-slate-850/50">
                  <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 rounded px-1">
                    <button
                      onClick={() => updateCartQty(item.product.id, item.quantity - 1)}
                      className="p-1 text-slate-400 hover:text-white"
                      disabled={item.product.isPhone}
                    >
                      <Minus size={11} />
                    </button>
                    <span className="text-xs font-bold font-mono text-indigo-400 px-1">{item.quantity}</span>
                    <button
                      onClick={() => updateCartQty(item.product.id, item.quantity + 1)}
                      className="p-1 text-slate-400 hover:text-white"
                      disabled={item.product.isPhone}
                    >
                      <Plus size={11} />
                    </button>
                  </div>

                  {/* Customizable item discount block */}
                  <div className="flex items-center gap-1 text-[10px]">
                    <span className="text-slate-500 font-bold">Disc (৳):</span>
                    <input
                      type="number"
                      placeholder="0"
                      value={item.discount || ''}
                      onChange={(e) => updateCartItemDiscount(item.product.id, Number(e.target.value))}
                      className="w-14 bg-slate-950 border border-slate-850 rounded p-0.5 px-1 font-mono text-slate-200 text-center"
                    />
                  </div>

                  {/* Final computed item row price */}
                  <span className="font-mono font-bold text-slate-100">
                    {settings.currency}
                    {(((item.product.sellingPrice ?? 0) - (item.discount ?? 0)) * (item.quantity ?? 1)).toLocaleString()}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Calculation Details, Coupons & Checkout Panel (Consolidated Footer) */}
        <div className="border-t border-slate-800 pt-4 space-y-4 shrink-0">
          
          {/* Coupon inputs */}
          <div className="flex gap-2">
            <div className="relative w-full">
              <Ticket className="absolute left-2.5 top-2 text-slate-500" size={13} />
              <input
                type="text"
                placeholder="Apply dynamic promo code..."
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 uppercase placeholder:normal-case font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
            <button
              onClick={handleValidateCoupon}
              className="px-3 py-1.5 bg-slate-950 hover:bg-slate-850 text-indigo-400 hover:text-white rounded-lg text-xs font-bold border border-slate-800 font-mono flex items-center gap-1"
            >
              Apply
            </button>
          </div>

          {appliedCoupon && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-2 flex items-center justify-between text-[11px] text-emerald-400">
              <span className="font-bold flex items-center gap-1.5">
                <Check size={12} /> Verification: Coupon "{appliedCoupon.code}" Accepted
              </span>
              <span className="font-bold font-mono">
                -{settings.currency}
                {couponDiscountAmount.toLocaleString()}
              </span>
            </div>
          )}

          {/* Pricing parameters details */}
          <div className="bg-slate-950/30 p-3 rounded-xl border border-slate-850/70 text-xs space-y-1.5 leading-normal">
            <div className="flex justify-between text-slate-400 font-medium">
              <span>Cart Subtotal:</span>
              <span className="font-mono font-bold text-slate-300">
                {settings.currency}
                {cartSubtotal.toLocaleString()}
              </span>
            </div>
            {couponDiscountAmount > 0 && (
              <div className="flex justify-between text-emerald-400 font-medium">
                <span>Promo Coupon Reduction:</span>
                <span className="font-mono font-bold">
                  -{settings.currency}
                  {couponDiscountAmount.toLocaleString()}
                </span>
              </div>
            )}
            <div className="flex justify-between text-slate-400 font-medium">
              <span>Vat Surcharge ({settings.vatPercent}%):</span>
              <span className="font-mono font-bold text-slate-300">
                {settings.currency}
                {taxAmount.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between text-slate-100 font-bold border-t border-slate-800/80 pt-1.5 text-sm">
              <span>Payable Total:</span>
              <span className="font-mono text-emerald-400">
                {settings.currency}
                {cartTotal.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Bangla MFS & Card payment methods select list */}
          <div className="space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">MFS & Payment Account selection</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setSelectedPaymentMethod('Cash')}
                className={`py-2 px-1 rounded-lg text-xs font-bold border transition-all text-center flex flex-col justify-center items-center gap-0.5 ${
                  selectedPaymentMethod === 'Cash'
                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-500/10'
                    : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-white'
                }`}
              >
                <span>🏦 Cash Drawer</span>
              </button>

              <button
                onClick={() => setSelectedPaymentMethod('bKash')}
                className={`py-2 px-1 rounded-lg text-[11px] font-bold border transition-all text-center flex flex-col justify-center items-center gap-0.5 ${
                  selectedPaymentMethod === 'bKash'
                    ? 'bg-pink-600 text-white border-pink-400 shadow-lg shadow-pink-500/10'
                    : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-white'
                }`}
              >
                <span>🎀 bKash Pay</span>
              </button>

              <button
                onClick={() => setSelectedPaymentMethod('Nagad')}
                className={`py-2 px-1 rounded-lg text-[11px] font-bold border transition-all text-center flex flex-col justify-center items-center gap-0.5 ${
                  selectedPaymentMethod === 'Nagad'
                    ? 'bg-orange-600 text-white border-orange-400 shadow-lg shadow-orange-500/10'
                    : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-white'
                }`}
              >
                <span>🔥 Nagad Pay</span>
              </button>
            </div>

            {/* Quick due balance calculations */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">Received Amt (৳)</label>
                <input
                  type="number"
                  placeholder="0"
                  value={paidAmount || ''}
                  onChange={(e) => setPaidAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2 text-xs font-mono font-bold text-slate-200"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold block mb-1">Outstanding Due Balance</label>
                <div className={`w-full border rounded-lg p-2 text-xs font-mono font-bold text-center ${dueAmount > 0 ? 'text-rose-400 border-rose-500/20 bg-rose-500/5' : 'text-emerald-400 border-slate-850 bg-slate-950'}`}>
                  {settings.currency}
                  {dueAmount.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Action trigger complete */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleResetPOS}
              className="py-2.5 bg-slate-955 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Clear Cart
            </button>
            <button
              onClick={handleCompletePaymentSale}
              disabled={cart.length === 0}
              className="py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:pointer-events-none text-white font-bold rounded-xl text-xs transition-shadow shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <FileText size={14} />
              <span>Checkout Invoice</span>
            </button>
          </div>

        </div>

      </div>

      {/* MODAL 1: IMEI SELECTOR MODAL FOR MOBILE DEVICES */}
      {imeiSelectionProduct && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div>
                <h4 className="text-sm font-bold text-slate-100">Select Device IMEIs</h4>
                <p className="text-[10px] text-slate-400">Model: {imeiSelectionProduct.name}</p>
              </div>
              <button
                onClick={() => setImeiSelectionProduct(null)}
                className="p-1 hover:bg-slate-800 rounded-md text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            {/* Checkbox box of available IMEI barcodes */}
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Available serial cards in store:</span>
              <div className="max-h-56 overflow-y-auto border border-slate-950 bg-slate-950/30 p-2 rounded-lg divide-y divide-slate-850/60 max-w-full">
                {imeiSelectionProduct.imeis.map((imei) => {
                  const isChecked = tempImeis.includes(imei);
                  return (
                    <label
                      key={imei}
                      className="py-2.5 px-1.5 flex items-center justify-between text-xs cursor-pointer select-none text-slate-300 hover:text-white transition-colors"
                    >
                      <span className="font-mono">{imei}</span>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {
                          if (isChecked) {
                            setTempImeis(prev => prev.filter(x => x !== imei));
                          } else {
                            setTempImeis(prev => [...prev, imei]);
                          }
                        }}
                        className="w-4 h-4 text-indigo-600 bg-slate-950 border-slate-800 rounded focus:ring-indigo-500 cursor-pointer"
                      />
                    </label>
                  );
                })}
                {imeiSelectionProduct.imeis.length === 0 && (
                  <p className="text-center py-6 text-xs text-slate-500 italic">No IMEIs currently registered for this smartphone device.</p>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center text-xs text-slate-400 border-t border-slate-800 pt-3">
              <span>Qty Selected: <strong className="text-indigo-400 font-bold font-mono">{tempImeis.length}</strong></span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setImeiSelectionProduct(null)}
                  className="px-3.5 py-1.5 border border-slate-800 hover:bg-slate-800 text-slate-300 rounded-lg text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApplyIMEIs}
                  disabled={tempImeis.length === 0}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold"
                >
                  Confirm Selection
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CUSTOMER INSTANT CREATOR ON POS */}
      {isCustomerModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <form onSubmit={handleTriggerQuickCustomer} className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 pb-2 border-b border-slate-850">
              <UserPlus size={16} className="text-indigo-400" />
              <span>On-the-spot Counter CRM entry</span>
            </h4>

            <div className="space-y-3">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shakil Ahmed"
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Mobile Contact Phone</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 017XXXXXXXX"
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Address / Hometown</label>
                <input
                  type="text"
                  placeholder="e.g. Bashundhara Residential, Dhaka"
                  value={newCustAddress}
                  onChange={(e) => setNewCustAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCustomerModalOpen(false)}
                className="px-3 py-1.5 border border-slate-800 text-slate-300 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
              >
                Add Customer
              </button>
            </div>
          </form>
        </div>
      )}

      {/* PREVIEW DRAWER 3: PRINTABLE INVOICE RECEIPT DRAWER */}
      {invoicePreviewSale && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col justify-between max-h-[90vh]">
            
            {/* Header bar */}
            <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-950/30 flex justify-between items-center shrink-0">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <Check size={16} /> POS Checkout Process Core Complete
              </span>
              <button
                onClick={() => setInvoicePreviewSale(null)}
                className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            {/* Invoicing Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 max-w-full">
              <div className="bg-white text-slate-900 p-6 rounded-lg shadow-inner font-sans border border-slate-200 max-w-[360px] mx-auto text-xs leading-normal select-text">
                
                {/* Store layout details */}
                <div className="text-center space-y-1 pb-3 border-b border-dashed border-slate-300">
                  <h5 className="font-extrabold text-base tracking-tight">{settings.shopName}</h5>
                  <p className="text-[9px] text-slate-500">{settings.address}</p>
                  <p className="text-[9px] text-slate-500 font-bold font-mono">Mobile: {settings.contactNo}</p>
                </div>

                {/* Counter invoice header details */}
                <div className="py-2.5 border-b border-dashed border-slate-300 space-y-0.5 text-[10px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Invoice Hash:</span>
                    <strong className="text-slate-900 font-bold font-mono">{invoicePreviewSale.invoiceNo}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Counter Clerk:</span>
                    <span className="font-semibold text-slate-900">Zahid Hasan (CEO)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Invoice Date:</span>
                    <span className="font-mono">{invoicePreviewSale.date}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-100 pt-1 mt-1 text-[11px] text-slate-900 font-bold">
                    <span>Buyer:</span>
                    <span>{invoicePreviewSale.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Buyer Contact:</span>
                    <span className="font-mono">{invoicePreviewSale.customerPhone}</span>
                  </div>
                </div>

                {/* Bought Item list row */}
                <div className="py-3 border-b border-dashed border-slate-300 space-y-2">
                  <div className="flex justify-between text-[10px] font-bold text-slate-500 leading-tight">
                    <span>Product Item Description</span>
                    <span>Item Net Total</span>
                  </div>
                  {invoicePreviewSale.items.map((item: any, idx: number) => (
                    <div key={idx} className="flex justify-between text-[11px] gap-2 leading-tight">
                      <div>
                        <span className="font-bold text-slate-950">{item.productName} [{item.model}]</span>
                        <p className="text-[9px] text-slate-500 mt-0.5 font-mono">
                          {item.quantity} units x ৳{(item.price - item.discount).toLocaleString()} 
                        </p>
                        {item.imeis?.length > 0 && (
                          <p className="text-[8px] text-indigo-700 font-mono font-semibold">IMEI: {item.imeis.join(', ')}</p>
                        )}
                      </div>
                      <span className="font-mono font-bold text-slate-950 whitespace-nowrap">
                        ৳{((item.price - item.discount) * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Subtotals & Math calculations */}
                <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 font-semibold text-[10px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Total Net Amount:</span>
                    <span className="font-mono">৳{invoicePreviewSale.subtotal.toLocaleString()}</span>
                  </div>
                  {invoicePreviewSale.couponDiscount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-bold">
                      <span>Promo Coupon Discount:</span>
                      <span className="font-mono">-৳{invoicePreviewSale.couponDiscount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Vat Surcharge / Tax ({settings.vatPercent}%):</span>
                    <span className="font-mono">৳{invoicePreviewSale.taxAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[13px] text-slate-900 border-t border-slate-100 pt-1 mt-1 font-bold">
                    <span>GRAND PAYABLE TOTAL:</span>
                    <span className="font-mono text-emerald-700">৳{invoicePreviewSale.total.toLocaleString()}</span>
                  </div>
                </div>

                {/* Wallet Payments metrics */}
                <div className="py-2.5 space-y-0.5 text-[10px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Settled via Account:</span>
                    <span className="font-bold text-slate-900">{invoicePreviewSale.paymentMethod?.split(' (')[0]}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Clerk Cash Received:</span>
                    <span className="font-mono text-slate-900">৳{invoicePreviewSale.paidAmount.toLocaleString()}</span>
                  </div>
                  {invoicePreviewSale.dueAmount > 0 && (
                    <div className="flex justify-between text-rose-600 font-extrabold border-t border-slate-100 pt-1 mt-1">
                      <span>Remaining Balance Due:</span>
                      <span className="font-mono">৳{invoicePreviewSale.dueAmount.toLocaleString()}</span>
                    </div>
                  )}
                </div>

                {/* Slogan Footer */}
                <div className="border-t border-dashed border-slate-300 pt-3 mt-1.5 text-center text-[9px] text-slate-500 font-medium leading-normal leading-relaxed">
                  <p>{settings.invoiceFooter}</p>
                  <p className="mt-1 font-semibold text-slate-700">Developed with ERP & POS Intel systems.</p>
                </div>

              </div>
            </div>

            {/* Print Control bars */}
            <div className="px-5 py-4 border-t border-slate-800 bg-slate-950/30 flex gap-2 shrink-0">
              <button
                onClick={() => setInvoicePreviewSale(null)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold"
              >
                Close Receipt
              </button>
              <button
                onClick={() => {
                  window.print();
                  setInvoicePreviewSale(null);
                }}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 font-mono shadow-md"
              >
                <Printer size={13} />
                <span>Simulate Print</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
