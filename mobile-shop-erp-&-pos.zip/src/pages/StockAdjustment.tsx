/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Workflow, Plus, Search, AlertTriangle, FileText, CheckCircle2, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const StockAdjustment: React.FC = () => {
  const { stockAdjustments, products, addStockAdjustment } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form states
  const [prodId, setProdId] = useState('');
  const [type, setType] = useState<'Addition' | 'Subtraction'>('Addition');
  const [qty, setQty] = useState(1);
  const [reason, setReason] = useState('Audit verification count');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodId) {
      alert('Must select a specific device product catalog registry item.');
      return;
    }
    if (qty <= 0) {
      alert('Quantity must exceed 0.');
      return;
    }

    const prod = products.find(p => p.id === prodId)!;

    addStockAdjustment({
      productId: prodId,
      productName: prod.name,
      type,
      quantity: qty,
      reason: reason.trim() || 'Manual stock override',
      adjustedBy: 'CEO Zahid Hasan'
    });

    setIsModalOpen(false);
    setProdId('');
    setQty(1);
    setReason('Audit verification count');
    alert('Stock audit adjustment lodged. Catalog quantity modified.');
  };

  const filteredAdjustments = stockAdjustments.filter(adj => {
    return adj.productName.toLowerCase().includes(searchTerm.toLowerCase()) || 
           adj.reason.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-6">
      
      {/* 1. Header component */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
            <Workflow size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Stock Audits & Adjustments</h2>
            <p className="text-[11px] text-slate-400">Log manual inventory additions or subtraction adjustments with legal audit trails</p>
          </div>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
        >
          <Plus size={15} />
          <span>Audit Stock Level</span>
        </button>
      </div>

      {/* 2. Searching items controller */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder="Search adjustments by name/reason..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none"
          />
        </div>
      </div>

      {/* Grid Table lists */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/15">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-401 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Adjustment ID</th>
                <th className="py-3 px-4">Lodge Date</th>
                <th className="py-3 px-4">Product Name Refer</th>
                <th className="py-3 px-4 text-center">Operation Type</th>
                <th className="py-3 px-4 text-right">Adjustment Qty</th>
                <th className="py-3 px-4">Reason Statement</th>
                <th className="py-3 px-4">Adjusted By Staff</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredAdjustments.map((adj) => (
                <tr key={adj.id} className="hover:bg-slate-800/15 text-slate-300">
                  <td className="py-3 px-4 font-mono font-bold text-slate-400">{adj.id}</td>
                  <td className="py-3 px-4 font-mono text-slate-400">{adj.date}</td>
                  <td className="py-3 px-4 font-bold text-slate-100">{adj.productName}</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                      adj.type === 'Addition' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-505/20' : 'bg-red-500/10 text-red-400 border border-red-505/20'
                    }`}>
                      {adj.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-200 text-sm">
                    {adj.type === 'Addition' ? '+' : '-'}
                    {adj.quantity} units
                  </td>
                  <td className="py-3 px-4 text-slate-350">{adj.reason}</td>
                  <td className="py-3 px-4 text-slate-400 text-xs font-semibold">{adj.adjustedBy}</td>
                </tr>
              ))}
              {filteredAdjustments.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No manual auditing stock overrides lodged in stock adjustments records.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* NEW AUDIT SLIDER MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 pb-2 border-b border-slate-850">
              <Workflow size={16} className="text-cyan-450 text-cyan-455 text-cyan-400" />
              <span>Record Stock Auditing Adjustment</span>
            </h4>

            <div className="space-y-3.5">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Target Device Catalog Item</label>
                <select
                  value={prodId}
                  onChange={(e) => setProdId(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                >
                  <option value="">-- Choose target item --</option>
                  {products.map(p => (
                    <option key={p.id} value={p.id}>{p.name} (Qty Left: {p.quantity})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Adjustment Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none font-bold"
                  >
                    <option value="Addition">Physical Addition (+)</option>
                    <option value="Subtraction">Physical Subtraction (-)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Count Qty</label>
                  <input
                    type="number"
                    required
                    placeholder="e.g. 1"
                    value={qty || ''}
                    onChange={(e) => setQty(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-mono font-bold focus:outline-none text-indigo-400"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Audit verification notes statement</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. damaged on-shelf, audit correction verify..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 border border-slate-800 text-slate-300 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-505 text-white rounded-lg text-xs font-bold font-mono shadow-md"
              >
                Authorize Overrides
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
