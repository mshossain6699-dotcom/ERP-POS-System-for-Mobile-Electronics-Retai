/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Wallet, MoveRight, ArrowDownLeft, ArrowUpRight, Search, Landmark, CreditCard, RefreshCw, Plus, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Accounting: React.FC = () => {
  const {
    accounts,
    transactions,
    transferFunds,
    depositWithdraw,
    settings
  } = useApp();

  const [activeTab, setActiveTab] = useState<'transfers' | 'manual'>('transfers');
  const [selectedTxAccount, setSelectedTxAccount] = useState(accounts[0]?.id || '');
  
  // Fund transfers states
  const [fromId, setFromId] = useState(accounts[0]?.id || '');
  const [toId, setToId] = useState(accounts[1]?.id || '');
  const [transferAmount, setTransferAmount] = useState(0);
  const [transferMemo, setTransferMemo] = useState('');

  // Manual Deposits / Withdraw states
  const [targetAccId, setTargetAccId] = useState(accounts[0]?.id || '');
  const [manualType, setManualType] = useState<'Deposit' | 'Withdrawal'>('Deposit');
  const [manualAmt, setManualAmt] = useState(0);
  const [manualMemo, setManualMemo] = useState('');

  // Transaction Lists search
  const [txSearch, setTxSearch] = useState('');

  // Execute transfer fund action
  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (fromId === toId) {
      alert('Source and destination accounts must differ.');
      return;
    }
    if (transferAmount <= 0) {
      alert('Amount must exceed 0.');
      return;
    }

    const success = transferFunds(fromId, toId, transferAmount, transferMemo.trim() || 'Internal Transfer');
    if (success) {
      alert('Funds successfully transferred. Ledgers balanced.');
      setTransferAmount(0);
      setTransferMemo('');
    } else {
      alert('Unsuccessful: Insufficient opening balance inside source account.');
    }
  };

  // Execute manual deposit / withdraw
  const handleManualTxSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualAmt <= 0) {
      alert('Verify amount is positive BDT values.');
      return;
    }

    const success = depositWithdraw(targetAccId, manualType, manualAmt, manualMemo.trim() || 'Manual adjustment');
    if (success) {
      alert(`Manual adjustment: ${manualType} successfully recorded.`);
      setManualAmt(0);
      setManualMemo('');
    } else {
      alert('Unsuccessful: Insufficient account balance to settle manual withdrawal.');
    }
  };

  // Filter transaction records
  const filteredTransactions = transactions.filter(tx => {
    const term = txSearch.toLowerCase();
    const accountObj = accounts.find(a => a.id === tx.accountId);
    return tx.description.toLowerCase().includes(term) ||
           tx.type.toLowerCase().includes(term) ||
           (accountObj && accountObj.name.toLowerCase().includes(term));
  });

  return (
    <div className="space-y-6">
      
      {/* 1. Accounts balance sheets cards row */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
        {accounts.map((acc) => {
          let shadowAccent = 'shadow-slate-950/20';
          let borderAccent = 'border-slate-800';
          let indicatorDot = 'bg-slate-400';

          if (acc.name.toLowerCase().includes('bkash')) {
            borderAccent = 'border-pink-500/10 hover:border-pink-500/30';
            shadowAccent = 'shadow-pink-500/5';
            indicatorDot = 'bg-pink-500';
          } else if (acc.name.toLowerCase().includes('nagad')) {
            borderAccent = 'border-orange-500/10 hover:border-orange-500/30';
            shadowAccent = 'shadow-orange-500/5';
            indicatorDot = 'bg-orange-500';
          } else if (acc.name.toLowerCase().includes('brac') || acc.name.toLowerCase().includes('bank')) {
            borderAccent = 'border-blue-500/1s shadow-blue-500/5 hover:border-blue-500/30';
            indicatorDot = 'bg-blue-400';
          } else if (acc.name.toLowerCase().includes('cash') || acc.name.toLowerCase().includes('register')) {
            borderAccent = 'border-emerald-500/10 hover:border-emerald-500/30';
            indicatorDot = 'bg-emerald-400';
          }

          return (
            <div key={acc.id} className={`bg-slate-900 border ${borderAccent} rounded-2xl p-5 shadow-lg ${shadowAccent} relative overflow-hidden group transition-all hover:scale-[101%]`}>
              <div className="flex justify-between items-start text-slate-400 mb-2">
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${indicatorDot}`}></span>
                  <span className="text-[10px] font-bold uppercase tracking-wider">{acc.type} account</span>
                </div>
                <div className="p-2 bg-slate-800/60 rounded-xl">
                  {acc.type === 'Bank' ? <Landmark size={15} /> : acc.type === 'MFS' ? <CreditCard size={15} /> : <Wallet size={15} />}
                </div>
              </div>

              <h4 className="text-xs font-bold text-slate-200 truncate">{acc.name}</h4>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5">{acc.accountNo || 'Counter Registration Drawer'}</p>
              
              <div className="border-t border-slate-850/60 mt-3 pt-2.5 flex justify-between items-center shrink-0">
                <span className="text-[10px] text-slate-400">Available Balance</span>
                <span className="text-base font-extrabold font-mono text-slate-100">
                  {settings.currency}
                  {acc.balance.toLocaleString()}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 2. Dual action blocks: fund transfers and manual adjustments */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Actions panel span 5/12 */}
        <div className="xl:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-lg">
          <div>
            <div className="flex justify-between border-b border-slate-800 pb-3 mb-2 shrink-0">
              <h4 className="text-sm font-bold text-slate-100">Treasury Ledgers SettleDesk</h4>
              <div className="flex gap-1">
                <button
                  onClick={() => setActiveTab('transfers')}
                  className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-colors ${activeTab === 'transfers' ? 'bg-indigo-600 text-white' : 'bg-slate-950 text-slate-400'}`}
                >
                  Internal Transfer
                </button>
                <button
                  onClick={() => setActiveTab('manual')}
                  className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-colors ${activeTab === 'manual' ? 'bg-indigo-600 text-white' : 'bg-slate-950 text-slate-400'}`}
                >
                  Manual Journal Adjust
                </button>
              </div>
            </div>

            {/* WIZARD 1: INTERNAL TRANSFER WRITER */}
            {activeTab === 'transfers' ? (
              <form onSubmit={handleTransferSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Source Sender Account</label>
                    <select
                      value={fromId}
                      onChange={(e) => setFromId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                    >
                      {accounts.map(a => (
                        <option key={a.id} value={a.id} className="bg-slate-900">{a.name} (৳{a.balance.toLocaleString()})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Receiver Account</label>
                    <select
                      value={toId}
                      onChange={(e) => setToId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                    >
                      {accounts.map(a => (
                        <option key={a.id} value={a.id} className="bg-slate-900">{a.name} (৳{a.balance.toLocaleString()})</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Amount to Transfer (BDT)</label>
                  <input
                    type="number"
                    value={transferAmount || ''}
                    onChange={(e) => setTransferAmount(Number(e.target.value))}
                    required
                    placeholder="Enter amount value"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-mono font-bold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Ledge entry Memo description</label>
                  <input
                    type="text"
                    value={transferMemo}
                    onChange={(e) => setTransferMemo(e.target.value)}
                    placeholder="e.g. cash drawer to bKash Business wallet payout..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={transferAmount <= 0}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:pointer-events-none text-white rounded-lg text-xs font-bold font-mono transition-shadow shadow-md shadow-indigo-500/20 cursor-pointer"
                >
                  Confirm Double-Entry Fund Transfer
                </button>
              </form>
            ) : (
              /* WIZARD 2: MANUAL JOURNAL DEPOSIT/WITHDRAW ADJ */
              <form onSubmit={handleManualTxSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Target Account</label>
                    <select
                      value={targetAccId}
                      onChange={(e) => setTargetAccId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                    >
                      {accounts.map(a => (
                        <option key={a.id} value={a.id} className="bg-slate-900">{a.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Adjustment Type</label>
                    <select
                      value={manualType}
                      onChange={(e) => setManualType(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                    >
                      <option value="Deposit">Manual Deposit / Income Injection</option>
                      <option value="Withdrawal">Manual Withdrawal / Cash Reduction</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Amount value (BDT)</label>
                  <input
                    type="number"
                    value={manualAmt || ''}
                    onChange={(e) => setManualAmt(Number(e.target.value))}
                    required
                    placeholder="Enter amount value"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-mono font-bold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Audit Trail Memo Description</label>
                  <input
                    type="text"
                    value={manualMemo}
                    onChange={(e) => setManualMemo(e.target.value)}
                    placeholder="e.g. partner capital drawing, cash drawer balance fix..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={manualAmt <= 0}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:pointer-events-none text-white rounded-lg text-xs font-bold font-mono transition-shadow shadow-md shadow-indigo-500/20 cursor-pointer"
                >
                  Verify Audit Ledger Entry
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Transactions log list span 7/12 */}
        <div className="xl:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-lg">
          <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3 mb-4 shrink-0">
              <div>
                <h4 className="text-sm font-bold text-slate-100">Live Transaction Ledgers Audit History</h4>
                <p className="text-[10px] text-slate-400">Chronological list of POS inflows, bills, transfers and deposits</p>
              </div>
              <div className="relative w-44">
                <Search className="absolute left-2.5 top-2 text-slate-500" size={12} />
                <input
                  type="text"
                  placeholder="Filter by description..."
                  value={txSearch}
                  onChange={(e) => setTxSearch(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-2 py-1 text-[11px] text-slate-300 focus:outline-none"
                />
              </div>
            </div>

            {/* List Table records */}
            <div className="overflow-x-auto max-h-72 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800">
              <table className="w-full text-left text-[11px] border-collapse">
                <thead className="bg-slate-950 text-slate-450 font-bold sticky top-0 border-b border-slate-850">
                  <tr>
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-3">Debit Wallet</th>
                    <th className="py-2 px-3 text-center">Event Type</th>
                    <th className="py-2 px-3">Audit Details Description</th>
                    <th className="py-2 px-3 text-right">Settlement Val</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850 bg-slate-950/20">
                  {filteredTransactions.map((tx) => {
                    const linkedAcc = accounts.find(a => a.id === tx.accountId);
                    
                    let statusColor = 'text-slate-300';
                    let directionSign = '';
                    const txType = tx.type;

                    if (txType === 'Sale' || txType === 'Deposit' || txType === 'Income' || txType === 'Tfr In') {
                      statusColor = 'text-emerald-400';
                      directionSign = '+';
                    } else if (txType === 'Purchase' || txType === 'Withdrawal' || txType === 'Expense' || txType === 'Tfr Out') {
                      statusColor = 'text-rose-400';
                      directionSign = '-';
                    }

                    return (
                      <tr key={tx.id} className="hover:bg-slate-800/10 text-slate-300">
                        <td className="py-2 px-3 font-mono text-slate-450">{tx.date}</td>
                        <td className="py-2 px-3 font-bold">{linkedAcc?.name.split(' (')[0] || 'Primary Ledger'}</td>
                        <td className="py-2 px-3 text-center">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                            txType === 'Sale' || txType === 'Tfr In' || txType === 'Deposit'
                              ? 'bg-emerald-500/10 text-emerald-450 border border-emerald-500/15'
                              : 'bg-rose-500/10 text-rose-450 border border-rose-500/15'
                          }`}>
                            {txType}
                          </span>
                        </td>
                        <td className="py-2 px-3 leading-tight select-all">{tx.description}</td>
                        <td className={`py-2 px-3 text-right font-mono font-bold text-sm ${statusColor}`}>
                          {directionSign}
                          {settings.currency}
                          {tx.amount.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                  {filteredTransactions.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-500">
                        No transactions registered matching current description keys.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
