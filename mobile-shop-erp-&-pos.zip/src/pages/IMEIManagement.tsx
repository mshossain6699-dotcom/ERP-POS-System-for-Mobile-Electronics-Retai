/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Barcode, CheckCircle, ShieldCheck, ShoppingBag, ShoppingCart } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface TrackedImei {
  imei: string;
  productId: string;
  productName: string;
  brand: string;
  color: string;
  ram: string;
  storage: string;
  status: 'In Stock' | 'Sold';
  soldInvoiceNo?: string;
  soldCustomer?: string;
}

export const IMEIManagement: React.FC = () => {
  const { products, sales } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'All' | 'In Stock' | 'Sold'>('All');

  // AGGREGATE ALL IMEIS IN SYSTEM
  const allTrackedImeis: TrackedImei[] = [];

  // 1. Gather all IMEIs currently "In Stock" in catalog products
  products.forEach(p => {
    if (p.isPhone) {
      p.imeis.forEach(imei => {
        allTrackedImeis.push({
          imei,
          productId: p.id,
          productName: p.name,
          brand: p.brand,
          color: p.color,
          ram: p.ram,
          storage: p.storage,
          status: 'In Stock'
        });
      });
    }
  });

  // 2. Gather all IMEIs already "Sold" from invoice sales archives
  sales.forEach(sale => {
    sale.items.forEach(item => {
      if (item.isPhone && item.imeis) {
        item.imeis.forEach(imei => {
          // Prevent duplicates if already partially stored
          if (!allTrackedImeis.some(x => x.imei === imei)) {
            allTrackedImeis.push({
              imei,
              productId: item.productId,
              productName: item.productName,
              brand: item.productName.split(' ')[0] || 'Unknown', // generic brand backup
              color: 'Review specs under INV',
              ram: '',
              storage: '',
              status: 'Sold',
              soldInvoiceNo: sale.invoiceNo,
              soldCustomer: sale.customerName
            });
          }
        });
      }
    });
  });

  // Filter IMEIs list
  const filteredImeis = allTrackedImeis.filter(i => {
    const term = searchTerm.toLowerCase();
    const matchSearch = i.imei.toLowerCase().includes(term) ||
                        i.productName.toLowerCase().includes(term) ||
                        (i.soldInvoiceNo && i.soldInvoiceNo.toLowerCase().includes(term)) ||
                        (i.soldCustomer && i.soldCustomer.toLowerCase().includes(term));
    const matchStatus = selectedStatus === 'All' || i.status === selectedStatus;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* KPI info headers */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-500">
            <Barcode size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">IMEI Serialization Database</h2>
            <p className="text-[11px] text-slate-400">Verifiable trace and registry tracking for smartphones and feature modules</p>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="text-center">
            <span className="text-[10px] text-slate-400 block uppercase font-bold text-left">Active In-Store IMEIs</span>
            <strong className="text-sm text-emerald-400 font-mono font-bold leading-none">
              {allTrackedImeis.filter(x => x.status === 'In Stock').length} serials
            </strong>
          </div>
          <div className="border-l border-slate-800 my-1"></div>
          <div className="text-center">
            <span className="text-[10px] text-slate-400 block uppercase font-bold text-left">Total Dispatched (Sold)</span>
            <strong className="text-sm text-indigo-400 font-mono font-bold leading-none">
              {allTrackedImeis.filter(x => x.status === 'Sold').length} serials
            </strong>
          </div>
        </div>
      </div>

      {/* Inputs controls */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="md:col-span-3 relative">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder="Scan or search specific IMEI serial code, model names, buyer profiles..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-650 focus:outline-none focus:border-indigo-500 font-mono"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-bold whitespace-nowrap">Filter Status:</span>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value as any)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-slate-300 focus:outline-none"
          >
            <option value="All">All Serial Tracks</option>
            <option value="In Stock">In Stock / Available</option>
            <option value="Sold">Sold / Dispatched</option>
          </select>
        </div>
      </div>

      {/* IMEI details grid table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/10">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">IMEI Serial BARCODE</th>
                <th className="py-3 px-4">Device Product Model Case</th>
                <th className="py-3 px-4">Manufacturer</th>
                <th className="py-3 px-4">Specifications Color</th>
                <th className="py-3 px-4 text-center">Tracking Status</th>
                <th className="py-3 px-4">Dispatched Log / Client info</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredImeis.map((item, index) => {
                let statusBadge = 'bg-emerald-500/10 text-emerald-400 border border-emerald-505/20';
                if (item.status === 'Sold') {
                  statusBadge = 'bg-indigo-500/10 text-indigo-400 border border-indigo-505/20';
                }

                return (
                  <tr key={index} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-3.5 px-4 font-mono font-extrabold text-slate-200 select-all tracking-wider text-xs flex items-center gap-2">
                      <Barcode size={14} className="text-slate-500" />
                      <span>{item.imei}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-100">{item.productName}</span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 font-medium">{item.brand}</td>
                    <td className="py-3.5 px-4">
                      {item.ram ? (
                        <span className="bg-slate-800/60 px-1.5 py-0.5 rounded text-[10px] font-semibold text-slate-400">
                          {item.ram}/{item.storage} • {item.color}
                        </span>
                      ) : (
                        <span className="italic text-slate-500 text-[10px]">{item.color}</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold flex items-center justify-center gap-1.5 mx-auto max-w-[100px] ${statusBadge}`}>
                        {item.status === 'In Stock' ? (
                          <>
                            <ShieldCheck size={12} /> In Stock
                          </>
                        ) : (
                          <>
                            <ShoppingBag size={12} /> Sold
                          </>
                        )}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      {item.status === 'Sold' ? (
                        <div className="text-[11px]">
                          <strong className="text-slate-200 font-mono font-extrabold block text-indigo-400">{item.soldInvoiceNo}</strong>
                          <span className="text-[10px] text-slate-400 mt-0.5 font-bold flex items-center gap-1">
                            Buyer: {item.soldCustomer}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-500 italic text-[11px]">Physical device in catalog shelf</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filteredImeis.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500 text-xs">
                    No IMEI codes matching parameters detected down database registers.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
