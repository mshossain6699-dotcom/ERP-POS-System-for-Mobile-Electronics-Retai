/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Receipt, Plus, Search, HelpCircle, FileText, AlertCircle, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Expenses: React.FC = () => {
  const { expenses, accounts, addExpense, settings } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form states
  const [desc, setDesc] = useState('');
  const [cat, setCat] = useState('Rent');
  const [amt, setAmt] = useState(0);
  const [accName, setAccName] = useState('Cash Register (Drawer)');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc.trim()) {
      alert('Description must details charge parameters.');
      return;
    }
    if (amt <= 0) {
      alert('Amount values must exceed 0.');
      return;
    }

    addExpense({
      date: new Date().toISOString().split('T')[0],
      description: desc.trim(),
      category: cat,
      amount: amt,
      paymentAccount: accName
    });

    setIsModalOpen(false);
    setDesc('');
    setAmt(0);
    alert('Shop Expense successfully tracked. Balance updated.');
  };

  const filteredExpenses = expenses.filter(e => {
    const term = searchTerm.toLowerCase();
    return e.description.toLowerCase().includes(term) ||
           e.category.toLowerCase().includes(term) ||
           e.paymentAccount.toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      
      {/* 1. Statistics Cards */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400">
            <Receipt size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Daily Operating Expenses</h2>
            <p className="text-[11px] text-slate-400">Track miscellaneous rent, power, utility, logistics charges and salaries</p>
          </div>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
        >
          <Plus size={15} />
          <span>Lodge Expense Invoice</span>
        </button>
      </div>

      {/* 2. Controls and ledger list */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder="Search by description or category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none"
          />
        </div>
      </div>

      {/* Grid list Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/10">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Charge ID</th>
                <th className="py-3 px-4">Lodge Date</th>
                <th className="py-3 px-4">Parameter Category</th>
                <th className="py-3 px-4">Description Audit Note</th>
                <th className="py-3 px-4">Debited From Account</th>
                <th className="py-3 px-4 text-right font-normal">Amount Charged</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredExpenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-800/15 text-slate-300">
                  <td className="py-3 px-4 font-mono font-bold text-slate-400">{exp.id}</td>
                  <td className="py-3 px-4 font-mono text-slate-400">{exp.date}</td>
                  <td className="py-3 px-4">
                    <span className="bg-red-500/10 border border-red-500/20 text-red-400 font-bold text-[9px] px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                      {exp.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 select-all">{exp.description}</td>
                  <td className="py-3 px-4 font-medium text-slate-400">{exp.paymentAccount?.split(' (')[0]}</td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-455 text-rose-400 text-sm">
                    -{settings.currency}
                    {exp.amount.toLocaleString()}
                  </td>
                </tr>
              ))}
              {filteredExpenses.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No operating expenses logged inside database folders.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* NEW EXPENSE INVOICE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5 pb-2 border-b border-slate-850">
              <Plus size={16} className="text-red-400" />
              <span>Record Operating Expense Cargo</span>
            </h4>

            <div className="space-y-3.5">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Expense Account Category</label>
                <select
                  value={cat}
                  onChange={(e) => setCat(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 font-bold focus:outline-none"
                >
                  <option value="Rent">Shop Rental</option>
                  <option value="Utilities">Utilities Electricity / Internet</option>
                  <option value="Salaries">Employee Salaries</option>
                  <option value="Logistics">Transport freight Courier</option>
                  <option value="Entertainment">Entertainment Food & tea</option>
                  <option value="Maintenance">Shop repair / Tech audit</option>
                  <option value="Marketing">Marketing / banner designs</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Charge Sum Amount (BDT)</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 500 BDT"
                  value={amt || ''}
                  onChange={(e) => setAmt(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-250 font-mono font-bold focus:outline-none text-rose-455 text-rose-400"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Audit description parameter</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dhaka Electric power bill June"
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Source account wallet debited</label>
                <select
                  value={accName}
                  onChange={(e) => setAccName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none"
                >
                  {accounts.map(a => (
                    <option key={a.id} value={a.name} className="bg-slate-900">{a.name} (৳{a.balance.toLocaleString()})</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 border border-slate-800 text-slate-300 rounded-lg text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold font-mono shadow-md"
              >
                Log Expense
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
