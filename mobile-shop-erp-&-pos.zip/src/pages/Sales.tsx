/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Receipt, Calendar, Printer, FileText, CheckCircle2, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Sale } from '../types';

export const Sales: React.FC = () => {
  const { sales, settings } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);

  // Filter Sales list
  const filteredSales = sales.filter(s => {
    const term = searchTerm.toLowerCase();
    return s.invoiceNo.toLowerCase().includes(term) ||
           s.customerName.toLowerCase().includes(term) ||
           s.customerPhone.includes(term) ||
           s.paymentMethod.toString().toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      
      {/* Overview stats bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-xl text-teal-400">
            <Receipt size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">POS Sales Archives</h2>
            <p className="text-[11px] text-slate-400">Search, review and print previous billing invoices</p>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block uppercase font-bold">Total Recorded Transactions</span>
            <strong className="text-sm text-indigo-400 font-mono font-bold leading-none">{sales.length} invoices</strong>
          </div>
          <div className="border-l border-slate-800 my-1"></div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block uppercase font-bold">Consolidated Sales Gross</span>
            <strong className="text-sm text-emerald-400 font-mono font-bold leading-none">
              {settings.currency}
              {sales.reduce((sum, s) => sum + s.total, 0).toLocaleString()}
            </strong>
          </div>
        </div>
      </div>

      {/* Control / Search line */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder="Search invoice number, client name or contact number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-650 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Sales history Grid lists */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/10">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Invoice ID</th>
                <th className="py-3 px-4">Receipt Date</th>
                <th className="py-3 px-4">Customer Details</th>
                <th className="py-3 px-4 text-right">Items Sold</th>
                <th className="py-3 px-4 text-center">Payment Wallet</th>
                <th className="py-3 px-4 text-right font-normal">Subtotal</th>
                <th className="py-3 px-4 text-right">Invoice Sum</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredSales.map((s) => {
                let walletBadge = 'bg-slate-800 border-slate-700 text-slate-300';
                const pMethodName = s.paymentMethod.toString();
                if (pMethodName.includes('bKash')) walletBadge = 'bg-pink-500/10 border border-pink-500/20 text-pink-400';
                else if (pMethodName.includes('Nagad')) walletBadge = 'bg-orange-500/10 border border-orange-500/20 text-orange-400';
                else if (pMethodName.includes('Bank') || pMethodName.includes('BRAC')) walletBadge = 'bg-blue-500/10 border border-blue-500/20 text-blue-400';
                else if (pMethodName.includes('Cash')) walletBadge = 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400';

                return (
                  <tr key={s.id} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-3 px-4 font-mono font-extrabold text-indigo-400 select-all">{s.invoiceNo}</td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-400">{s.date}</td>
                    <td className="py-3 px-4">
                      <strong className="block text-slate-200">{s.customerName}</strong>
                      <span className="text-[10px] text-slate-500 font-mono">{s.customerPhone}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-indigo-400">
                      {s.items.reduce((sum, item) => sum + item.quantity, 0)} Units
                      <span className="block text-[9px] text-slate-500 font-normal">({s.items.length} unique items)</span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${walletBadge}`}>
                        {s.paymentMethod.toString().split(' (')[0]}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-400">
                      {settings.currency}
                      {s.subtotal.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-100 text-sm">
                      {settings.currency}
                      {s.total.toLocaleString()}
                      {s.dueAmount > 0 && (
                        <span className="block text-[8px] text-rose-400 font-bold uppercase tracking-wider font-sans">
                          ৳{s.dueAmount.toLocaleString()} Due
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => setSelectedSale(s)}
                        className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-teal-600/10 hover:bg-teal-600 text-teal-400 hover:text-white border border-teal-500/15 transition-all cursor-pointer"
                      >
                        Launch Invoice
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredSales.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500 text-xs">
                    No matching sales transactions located inside system.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* DYNAMIC BACK INVOICE PREVIEW DIALOG MODAL */}
      {selectedSale && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col justify-between max-h-[90vh]">
            
            <div className="px-5 py-3 border-b border-slate-800 flex justify-between items-center text-slate-200 bg-slate-950/30 shrink-0">
              <span className="text-xs font-bold font-mono">Invoice Viewer: {selectedSale.invoiceNo}</span>
              <button onClick={() => setSelectedSale(null)} className="p-1 hover:bg-slate-850 rounded text-slate-400 hover:text-white">
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4 max-w-full z-10 select-all">
              <div className="bg-white text-slate-900 p-6 rounded-lg shadow-md font-sans border border-slate-200 max-w-[360px] mx-auto text-xs leading-normal">
                
                <div className="text-center space-y-1 pb-3 border-b border-dashed border-slate-300">
                  <h5 className="font-extrabold text-base tracking-tight">{settings.shopName}</h5>
                  <p className="text-[9px] text-slate-500">{settings.address}</p>
                  <p className="text-[9px] text-slate-500 font-bold font-mono">Mobile: {settings.contactNo}</p>
                </div>

                <div className="py-2.5 border-b border-dashed border-slate-300 space-y-0.5 text-[10px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Invoice Hash:</span>
                    <strong className="text-slate-900 font-bold font-mono">{selectedSale.invoiceNo}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Transaction Clerk:</span>
                    <span className="font-semibold text-slate-900">Zahid Hasan (CEO)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Date:</span>
                    <span className="font-mono">{selectedSale.date}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-100 pt-1 mt-1 text-[11px] text-slate-900 font-bold">
                    <span>Buyer Name:</span>
                    <span>{selectedSale.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Buyer Phone:</span>
                    <span className="font-mono">{selectedSale.customerPhone}</span>
                  </div>
                </div>

                <div className="py-3 border-b border-dashed border-slate-300 space-y-2">
                  <div className="flex justify-between text-[10px] font-bold text-slate-500 leading-tight">
                    <span>Product Item Description</span>
                    <span>Item Net Total</span>
                  </div>
                  {selectedSale.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-[11px] gap-2 leading-tight">
                      <div>
                        <span className="font-bold text-slate-950">{item.productName} [{item.model}]</span>
                        <p className="text-[9px] text-slate-500 mt-0.5 font-mono">
                          {item.quantity} units x ৳{(item.price - item.discount).toLocaleString()} 
                        </p>
                        {item.imeis?.length > 0 && (
                          <p className="text-[8px] text-indigo-700 font-mono font-semibold">IMEI: {item.imeis.join(', ')}</p>
                        )}
                      </div>
                      <span className="font-mono font-bold text-slate-950 whitespace-nowrap">
                        ৳{((item.price - item.discount) * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 font-semibold text-[10px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Cart Total Net:</span>
                    <span className="font-mono">৳{selectedSale.subtotal.toLocaleString()}</span>
                  </div>
                  {selectedSale.couponDiscount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-bold">
                      <span>Promo Coupon Discount:</span>
                      <span className="font-mono">-৳{selectedSale.couponDiscount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Vat Surcharge ({settings.vatPercent}%):</span>
                    <span className="font-mono">৳{selectedSale.taxAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[13px] text-slate-900 border-t border-slate-100 pt-1 mt-1 font-bold">
                    <span>GRAND TOTAL CHARGED:</span>
                    <span className="font-mono text-emerald-700">৳{selectedSale.total.toLocaleString()}</span>
                  </div>
                </div>

                <div className="py-2.5 space-y-0.5 text-[10px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Settled via Account:</span>
                    <span className="font-bold text-slate-900 text-[9px]">{selectedSale.paymentMethod?.toString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Clerk Cash Received:</span>
                    <span className="font-mono text-slate-900">৳{selectedSale.paidAmount.toLocaleString()}</span>
                  </div>
                  {selectedSale.dueAmount > 0 && (
                    <div className="flex justify-between text-rose-600 font-extrabold border-t border-slate-100 pt-1 mt-1">
                      <span>Remaining Balance Due:</span>
                      <span className="font-mono">৳{selectedSale.dueAmount.toLocaleString()}</span>
                    </div>
                  )}
                </div>

                <div className="border-t border-dashed border-slate-300 pt-3 mt-1.5 text-center text-[9px] text-slate-500 font-medium leading-relaxed">
                  <p>{settings.invoiceFooter}</p>
                </div>

              </div>
            </div>

            <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/30 flex gap-2 shrink-0">
              <button
                onClick={() => setSelectedSale(null)}
                className="w-full py-2 bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs font-bold"
              >
                Close Dialog
              </button>
              <button
                onClick={() => window.print()}
                className="w-full py-2 bg-teal-600 hover:bg-teal-500 text-white font-mono rounded-lg text-xs font-bold flex items-center justify-center gap-1"
              >
                <Printer size={13} />
                <span>Print Copy</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
