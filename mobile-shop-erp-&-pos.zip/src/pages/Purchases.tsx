/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Download, Plus, Search, HelpCircle, FilePlus, ChevronDown, CheckCircle, AlertCircle, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product, Supplier } from '../types';

export const Purchases: React.FC = () => {
  const {
    purchases,
    products,
    suppliers,
    addPurchase,
    settings
  } = useApp();

  const [isNewOpen, setIsNewOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // New Purchase receipt wizard states
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || '');
  const [items, setItems] = useState<Array<{
    productId: string;
    productName: string;
    isPhone: boolean;
    costPrice: number;
    quantity: number;
    imeisString: string;
  }>>([]);

  const [wizardProductId, setWizardProductId] = useState('');
  const [wizardQty, setWizardQty] = useState(1);
  const [wizardCost, setWizardCost] = useState(0);
  const [wizardImeis, setWizardImeis] = useState('');

  const [paidAmt, setPaidAmt] = useState(0);
  const [notes, setNotes] = useState('');
  const [payMethod, setPayMethod] = useState('BRAC Bank Business A/C');
  const [validationMsg, setValidationMsg] = useState('');

  const activeProduct = products.find(p => p.id === wizardProductId);

  // Auto wizard settings update
  const handleProductSelectChange = (pId: string) => {
    setWizardProductId(pId);
    const prodObj = products.find(p => p.id === pId);
    if (prodObj) {
      setWizardCost(prodObj.costPrice);
      setWizardQty(1);
      setWizardImeis('');
    }
  };

  // Add Item line definition
  const addItemWizardLine = () => {
    setValidationMsg('');
    if (!wizardProductId) {
      setValidationMsg('Select a target device catalog product from catalog.');
      return;
    }
    const prodObj = products.find(p => p.id === wizardProductId)!;
    
    // Check if phone and check IMEIs
    const imeisList = prodObj.isPhone
      ? wizardImeis.split('\n').map(i => i.trim()).filter(i => i.length > 0)
      : [];

    if (prodObj.isPhone && wizardQty !== imeisList.length) {
      setValidationMsg(`Serial Error: Brand Qty is set to ${wizardQty} devices but you only listed ${imeisList.length} serial IMEIs.`);
      return;
    }

    // Check duplicates
    if (items.some(x => x.productId === wizardProductId)) {
      setValidationMsg('This product line is already added to current purchase basket.');
      return;
    }

    setItems(prev => [...prev, {
      productId: wizardProductId,
      productName: prodObj.name,
      isPhone: prodObj.isPhone,
      costPrice: Number(wizardCost),
      quantity: Number(wizardQty),
      imeisString: wizardImeis.trim()
    }]);

    // reset fields
    setWizardProductId('');
    setWizardQty(1);
    setWizardCost(0);
    setWizardImeis('');
  };

  const handleRemoveLine = (idx: number) => {
    setItems(prev => prev.filter((_, i) => i !== idx));
  };

  // Calculations
  const purchaseTotal = items.reduce((sum, item) => sum + (item.costPrice * item.quantity), 0);
  const purchaseDue = Math.max(0, purchaseTotal - paidAmt);

  // Submit complete
  const handleCheckoutPurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      alert('Cannot check post an empty supply order basket.');
      return;
    }
    if (!selectedSupplierId) {
      alert('You must link this purchase transaction to an active Supplier counterparty.');
      return;
    }

    const supplierObj = suppliers.find(s => s.id === selectedSupplierId)!;

    const formattedLines = items.map(line => ({
      productId: line.productId,
      productName: line.productName,
      costPrice: line.costPrice,
      quantity: line.quantity,
      imeis: line.isPhone ? line.imeisString.split('\n').map(i => i.trim()).filter(i => i.length > 0) : []
    }));

    addPurchase({
      date: new Date().toISOString().split('T')[0],
      supplierId: selectedSupplierId,
      supplierName: supplierObj.name,
      items: formattedLines,
      total: purchaseTotal,
      paidAmount: paidAmt,
      dueAmount: purchaseDue,
      paymentMethod: payMethod,
      notes
    });

    // Reset layout
    setIsNewOpen(false);
    setItems([]);
    setPaidAmt(0);
    setNotes('');
    alert('Purchase restock supply recorded. Product quantities shifted in catalog.');
  };

  // Filtering Purchases
  const filteredPurchases = purchases.filter(p => {
    const term = searchTerm.toLowerCase();
    return p.supplierName.toLowerCase().includes(term) ||
           p.id.toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      
      {/* 1. Header block */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
            <Download size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Vendor Stock Purchasing Hub</h2>
            <p className="text-[11px] text-slate-400">Record incoming supplier restocks and update item quantities</p>
          </div>
        </div>

        <button
          onClick={() => {
            setIsNewOpen(true);
            setSelectedSupplierId(suppliers[0]?.id || '');
          }}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shadow-indigo-500/25 active:scale-95 cursor-pointer"
        >
          <Plus size={15} />
          <span>New Supplier Order</span>
        </button>
      </div>

      {/* 2. Controls Search bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={15} />
          <input
            type="text"
            placeholder="Search vendor supplier name / purchase ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none"
          />
        </div>
      </div>

      {/* Table grid of records */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Purchase Order ID</th>
                <th className="py-3 px-4">Order Date</th>
                <th className="py-3 px-4">Linked Supplier Counterparty</th>
                <th className="py-3 px-4 text-center">Items Ordered</th>
                <th className="py-3 px-4">Settle Account</th>
                <th className="py-3 px-4 text-right">Settled Amt</th>
                <th className="py-3 px-4 text-right">Outstanding Bill</th>
                <th className="py-3 px-4 text-right font-semibold">Total Invoice</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredPurchases.map((p) => {
                const totalQty = p.items.reduce((sum, item) => sum + item.quantity, 0);
                
                return (
                  <tr key={p.id} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-3 px-4 font-mono font-extrabold text-indigo-400 select-all">{p.id}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{p.date}</td>
                    <td className="py-3 px-4">
                      <strong className="text-slate-200">{p.supplierName}</strong>
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-indigo-400">
                      {totalQty} Units
                      <span className="block text-[9px] text-slate-500 font-normal">({p.items.length} product lines)</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[10px] text-slate-400 font-semibold">{p.paymentMethod}</span>
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-400 font-bold font-mono">
                      {settings.currency}
                      {p.paidAmount.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-rose-400 font-mono">
                      {settings.currency}
                      {p.dueAmount.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-100 font-extrabold font-mono text-sm">
                      {settings.currency}
                      {p.total.toLocaleString()}
                    </td>
                  </tr>
                );
              })}
              {filteredPurchases.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500 text-xs">
                    No supplier records lodged inside ERP purchase files.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* NEW ORDER RESTOCK MODAL */}
      {isNewOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/30 flex justify-between items-center shrink-0">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <FilePlus className="text-indigo-400" size={18} />
                <span>Register Incoming Supplier Cargo Delivery</span>
              </h3>
              <button onClick={() => setIsNewOpen(false)} className="p-1 hover:bg-slate-850 rounded text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCheckoutPurchase} className="flex-1 overflow-y-auto p-6 space-y-4">
              
              {/* Supplier & account configurations */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Select Supplier counterparty</label>
                  <select
                    value={selectedSupplierId}
                    onChange={(e) => setSelectedSupplierId(e.target.value)}
                    required
                    className="w-full bg-slate-100/10 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 font-bold focus:outline-none"
                  >
                    <option value="" disabled className="bg-slate-900 font-bold text-slate-400">Choose supplier</option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id} className="bg-slate-900 font-bold text-slate-300">
                        {s.name} ({s.company})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Debited Account Source</label>
                  <select
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value)}
                    className="w-full bg-slate-100/10 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none"
                  >
                    <option value="BRAC Bank Business A/C" className="bg-slate-900">BRAC Bank Business A/C</option>
                    <option value="Cash Register (Drawer)" className="bg-slate-900">Cash Register (Drawer)</option>
                    <option value="bKash Merchant Account" className="bg-slate-900">bKash Merchant Account</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Supplier Memo / Notes</label>
                  <input
                    type="text"
                    placeholder="Batch series XYZ, warranty terms..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              {/* DYNAMIC LINE BUILDER DESK */}
              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-850 space-y-3.5">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">Incoming Line Builder Wizard</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 block mb-0.5">Select Catalog Product</label>
                    <select
                      value={wizardProductId}
                      onChange={(e) => handleProductSelectChange(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-300 focus:outline-none"
                    >
                      <option value="">-- Choose item --</option>
                      {products.map(p => (
                        <option key={p.id} value={p.id}>{p.name} {p.isPhone ? '(Serial phone)' : '(General Item)'}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[9px] font-bold text-slate-400 block mb-0.5">Unit Buying Cost (BDT)</label>
                    <input
                      type="number"
                      value={wizardCost || ''}
                      onChange={(e) => setWizardCost(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-200 font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-[9px] font-bold text-slate-400 block mb-0.5">Quantity Restocking</label>
                    <input
                      type="number"
                      value={wizardQty || ''}
                      onChange={(e) => setWizardQty(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-200 font-bold"
                    />
                  </div>
                </div>

                {activeProduct?.isPhone && (
                  <div className="space-y-1">
                    <div className="text-[9px] text-slate-400 font-bold flex justify-between uppercase">
                      <span>Provide new Serial IMEIs (One IMEI per row)</span>
                      <span className="text-indigo-400 font-extrabold">{wizardQty} rows required</span>
                    </div>
                    <textarea
                      rows={3}
                      placeholder="Enter unique IMEIs serials batch code..."
                      value={wizardImeis}
                      onChange={(e) => setWizardImeis(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs font-mono text-slate-200 focus:outline-none"
                    />
                  </div>
                )}

                <div className="flex justify-between items-center pt-2">
                  <div className="text-[10px] text-rose-400 font-semibold">{validationMsg}</div>
                  <button
                    type="button"
                    onClick={addItemWizardLine}
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold font-mono transition-all active:scale-95"
                  >
                    + Bind Line to Basket
                  </button>
                </div>
              </div>

              {/* Render lines in current cart basket */}
              {items.length > 0 && (
                <div className="border border-slate-850 rounded-xl overflow-hidden bg-slate-950/30">
                  <table className="w-full text-left text-[11px] border-collapse">
                    <thead className="bg-slate-950 text-slate-450 border-b border-slate-850">
                      <tr>
                        <th className="py-2 px-3">Product Item Description</th>
                        <th className="py-2 px-3 text-right">Bind Cost</th>
                        <th className="py-2 px-3 text-right">Quantity</th>
                        <th className="py-2 px-3">Enrolled Serials (IMEIs)</th>
                        <th className="py-2 px-3 text-right">Total Line Sum</th>
                        <th className="py-2 px-3 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {items.map((line, index) => (
                        <tr key={index} className="hover:bg-slate-800/10 text-slate-300">
                          <td className="py-2 px-3 font-bold text-slate-200">{line.productName}</td>
                          <td className="py-2 px-3 text-right font-mono text-slate-100">৳{line.costPrice.toLocaleString()}</td>
                          <td className="py-2 px-3 text-right font-bold text-indigo-400">{line.quantity}</td>
                          <td className="py-2 px-3 max-w-[200px] truncate leading-tight font-mono text-[9px] text-slate-450">
                            {line.isPhone ? line.imeisString.split('\n').join(', ') : 'Accessories (No serial)'}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-100">
                            ৳{(line.costPrice * line.quantity).toLocaleString()}
                          </td>
                          <td className="py-1 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveLine(index)}
                              className="p-1 text-rose-400 hover:bg-rose-950 rounded"
                            >
                              <X size={12} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Settlement summary details */}
              <div className="border shadow-inner border-slate-850 bg-slate-950/20 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="flex gap-4 text-xs font-semibold leading-normal">
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase font-bold">Total Bill Sum:</span>
                    <strong className="text-base text-slate-100 font-mono font-bold">৳{purchaseTotal.toLocaleString()}</strong>
                  </div>
                  <div className="border-l border-slate-800 my-1"></div>
                  <div>
                    <span className="text-slate-400 block text-[9px] uppercase font-bold">Outstanding Bill Due:</span>
                    <strong className="text-base text-rose-400 font-mono font-bold">৳{purchaseDue.toLocaleString()}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400 block font-bold">Cash Account Disbursed (৳):</span>
                  <input
                    type="number"
                    value={paidAmt || ''}
                    onChange={(e) => setPaidAmt(Number(e.target.value))}
                    placeholder="Enter sum paid"
                    className="w-32 bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono font-bold text-slate-200"
                  />
                </div>
              </div>

              {/* Control Buttons row */}
              <div className="flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsNewOpen(false)}
                  className="px-4 py-2 border border-slate-800 text-slate-300 hover:text-white rounded-lg text-xs font-bold"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  disabled={items.length === 0}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold font-mono transition-shadow shadow-md shadow-indigo-500/20"
                >
                  Verify & Lodge Delivery
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
