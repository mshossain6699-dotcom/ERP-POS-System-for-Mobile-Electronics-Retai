/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ChartLine, TrendingUp, Landmark, ShieldCheck, ShoppingBag, ReceiptCent, DollarSign, WalletCards } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Reports: React.FC = () => {
  const { sales, purchases, expenses, products, settings } = useApp();

  // Aggregate stats
  const totalSalesRevenue = sales.reduce((sum, s) => sum + s.total, 0);
  const totalPurchasesBill = purchases.reduce((sum, p) => sum + p.total, 0);
  const totalOperatingChgs = expenses.reduce((sum, e) => sum + e.amount, 0);

  // COGS Calculation (Cost of Goods Sold)
  // Let's deduce COGS based on costPrice defined in product objects matching items sold quantity
  let estimatedCOGS = 0;
  sales.forEach(sale => {
    sale.items.forEach(item => {
      // Find matching catalog product
      const catProd = products.find(p => p.id === item.productId);
      const buyingCost = catProd ? catProd.costPrice : (item.price * 0.75); // fallback approximation
      estimatedCOGS += (buyingCost * item.quantity);
    });
  });

  const grossProfitMultiplier = totalSalesRevenue - estimatedCOGS;
  const netProfitSurplus = grossProfitMultiplier - totalOperatingChgs;

  // Inventory value approximation
  const totalInventoryValueCost = products.reduce((sum, p) => sum + (p.costPrice * p.quantity), 0);
  const totalInventoryRetailVal = products.reduce((sum, p) => sum + (p.sellingPrice * p.quantity), 0);
  const potentialAssetMargins = totalInventoryRetailVal - totalInventoryValueCost;

  return (
    <div className="space-y-6">
      
      {/* 1. Header label block */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-teal-500/10 border border-teal-500/20 rounded-xl text-teal-400">
            <ChartLine size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Strategic Performance Reports</h2>
            <p className="text-[11px] text-slate-400">Consolidated analytics showing sales margins, operating costs and venture profitability</p>
          </div>
        </div>

        <div className="text-xs uppercase bg-slate-950 px-3 py-1.5 border border-slate-800 rounded-lg text-slate-400 font-bold font-mono">
          Consolidated June 2026 Audit
        </div>
      </div>

      {/* 2. Executive Ledger Profit & Loss sheet statement */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
        
        {/* Sales Revenue card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col justify-between h-32">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Gross Sales Revenue</span>
            <strong className="text-2xl font-extrabold font-mono text-slate-150 text-slate-100 mt-2 block">
              ৳{totalSalesRevenue.toLocaleString()}
            </strong>
          </div>
          <span className="text-[9px] text-emerald-400 mt-1 font-bold">100% Core Cash/MFS Inflows</span>
        </div>

        {/* COGS bill card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col justify-between h-32">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Estimated Cost of Goods (COGS)</span>
            <strong className="text-2xl font-extrabold font-mono text-slate-100 mt-2 block">
              ৳{estimatedCOGS.toLocaleString()}
            </strong>
          </div>
          <span className="text-[9px] text-slate-500 mt-1">Acquisition capital on devices sold</span>
        </div>

        {/* Shop expenses charges */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col justify-between h-32">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Operating Expenses (OPEX)</span>
            <strong className="text-2xl font-extrabold font-mono text-rose-400 mt-2 block">
              ৳{totalOperatingChgs.toLocaleString()}
            </strong>
          </div>
          <span className="text-[9px] text-slate-500 mt-1">Rent, salaries & utilities ledger sum</span>
        </div>

        {/* Executive Profit / Loss Surplus */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col justify-between h-32">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Net Retained Surplus Margin</span>
            <strong className={`text-2xl font-extrabold font-mono mt-2 block ${netProfitSurplus >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              ৳{netProfitSurplus.toLocaleString()}
            </strong>
          </div>
          <span className="text-[9px] text-emerald-450 text-emerald-400 font-bold">
            {(totalSalesRevenue > 0 ? (netProfitSurplus / totalSalesRevenue) * 100 : 0).toFixed(1)}% Conversion profit-to-sales
          </span>
        </div>

      </div>

      {/* Bento grid detailed modules */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        {/* Inventory strategic investments values card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h4 className="text-xs font-extrabold text-slate-205 text-slate-250 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-800 pb-3">
            <ShoppingBag size={15} className="text-indigo-405" />
            <span>Shelved Asset Capital Valuations</span>
          </h4>

          <div className="space-y-4 text-xs font-semibold leading-normal">
            <div className="flex justify-between items-center bg-slate-950 p-3.5 rounded-xl border border-slate-850">
              <div>
                <span className="text-slate-400 text-[10px] block font-bold uppercase">Asset Sourcing Cost basis (COGS Stock)</span>
                <p className="text-[10px] text-slate-505">Sum capital held in shelves</p>
              </div>
              <strong className="text-base text-slate-100 font-mono font-bold">৳{totalInventoryValueCost.toLocaleString()}</strong>
            </div>

            <div className="flex justify-between items-center bg-slate-950 p-3.5 rounded-xl border border-slate-850">
              <div>
                <span className="text-slate-400 text-[10px] block font-bold uppercase">Expected Shelved Retail Value</span>
                <p className="text-[10px] text-slate-505">Potential revenue at normal retail values</p>
              </div>
              <strong className="text-base text-indigo-400 font-mono font-bold">৳{totalInventoryRetailVal.toLocaleString()}</strong>
            </div>

            <div className="flex justify-between items-center bg-slate-950 p-3.5 rounded-xl border border-slate-850">
              <div>
                <span className="text-slate-400 text-[10px] block font-bold uppercase">Shelved Profit Margins potential</span>
                <p className="text-[10px] text-slate-505">Profit once fully cleared</p>
              </div>
              <strong className="text-base text-emerald-400 font-mono font-bold">৳{potentialAssetMargins.toLocaleString()}</strong>
            </div>
          </div>
        </div>

        {/* Comparative breakdown tables */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h4 className="text-xs font-extrabold text-slate-205 text-slate-250 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-800 pb-3">
            <ReceiptCent size={15} className="text-rose-405 text-rose-455" />
            <span>Core OpEx Breakdown Charts</span>
          </h4>

          {/* List category breakdown */}
          <div className="space-y-3.5 text-xs font-semibold leading-normal">
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-bold uppercase">
                <span>Shop Rents</span>
                <span className="font-mono text-slate-200">
                  ৳{expenses.filter(e => e.category === 'Rent').reduce((sum, e) => sum + e.amount, 0).toLocaleString()}
                </span>
              </div>
              <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div className="bg-red-500 h-full rounded-full" style={{ width: '45%' }}></div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-bold uppercase">
                <span>Employee Salaries</span>
                <span className="font-mono text-slate-200">
                  ৳{expenses.filter(e => e.category === 'Salaries').reduce((sum, e) => sum + e.amount, 0).toLocaleString()}
                </span>
              </div>
              <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div className="bg-indigo-505 bg-indigo-500 h-full rounded-full" style={{ width: '38%' }}></div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-bold uppercase">
                <span>Utilities Power Internet</span>
                <span className="font-mono text-slate-200">
                  ৳{expenses.filter(e => e.category === 'Utilities').reduce((sum, e) => sum + e.amount, 0).toLocaleString()}
                </span>
              </div>
              <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '12%' }}></div>
              </div>
            </div>

            <div className="space-y-1 pb-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-bold uppercase">
                <span>Logistics and courier transport</span>
                <span className="font-mono text-slate-200">
                  ৳{expenses.filter(e => e.category === 'Logistics').reduce((sum, e) => sum + e.amount, 0).toLocaleString()}
                </span>
              </div>
              <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div className="bg-teal-500 h-full rounded-full" style={{ width: '5%' }}></div>
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
