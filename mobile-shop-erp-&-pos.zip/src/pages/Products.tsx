/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  AlertTriangle,
  Upload,
  Layers,
  Smartphone,
  ChevronRight,
  Sparkles,
  ClipboardCheck,
  CheckCircle2,
  TrendingUp,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { BulkImportDialog } from '../components/BulkImportDialog';

export const Products: React.FC = () => {
  const {
    products,
    categories,
    brands,
    addProduct,
    updateProduct,
    deleteProduct,
    bulkImportProducts,
    addCategory,
    addBrand,
    settings,
  } = useApp();

  // Dialog management
  const [isBulkOpen, setIsBulkOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Mini state triggers for adding inline Categories and Brands
  const [isAddingCat, setIsAddingCat] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [isAddingBrand, setIsAddingBrand] = useState(false);
  const [newBrandName, setNewBrandName] = useState('');

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  // Single Product Form State (Add / Edit)
  const defaultFormState = {
    name: '',
    model: '',
    brand: '',
    category: '',
    costPrice: 0,
    sellingPrice: 0,
    quantity: 0,
    imeisString: '',
    color: '',
    ram: 'N/A',
    storage: 'N/A',
    isPhone: true,
    lowStockLimit: 2,
  };
  const [form, setForm] = useState(defaultFormState);

  // Form Validation Message
  const [validationMsg, setValidationMsg] = useState('');

  // Action Edit Product Modal opener
  const openEditModal = (p: Product) => {
    setEditingId(p.id);
    setForm({
      name: p.name,
      model: p.model,
      brand: p.brand,
      category: p.category,
      costPrice: p.costPrice,
      sellingPrice: p.sellingPrice,
      quantity: p.quantity,
      imeisString: p.imeis.join('\n'),
      color: p.color,
      ram: p.ram,
      storage: p.storage,
      isPhone: p.isPhone,
      lowStockLimit: p.lowStockLimit,
    });
    setIsAddOpen(true);
  };

  // Opening the single add modal
  const openAddModal = () => {
    setEditingId(null);
    setForm({
      ...defaultFormState,
      brand: brands[0]?.name || 'Apple',
      category: categories[0]?.name || 'Smartphones',
    });
    setIsAddOpen(true);
    setValidationMsg('');
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setForm(prev => ({
        ...prev,
        [name]: checked,
        // Reset properties if no longer a phone
        ram: checked ? '8GB' : 'N/A',
        storage: checked ? '256GB' : 'N/A',
        imeisString: checked ? prev.imeisString : '',
      }));
    } else {
      setForm(prev => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  // Submit Product Add / Edit
  const handleSubmitProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationMsg('');

    if (!form.name.trim() || !form.model.trim()) {
      setValidationMsg('Product Name & Model identification are mandatory.');
      return;
    }

    if (form.costPrice <= 0 || form.sellingPrice <= 0) {
      setValidationMsg('Verify buying and selling prices are positive.');
      return;
    }

    const imeis = form.isPhone
      ? form.imeisString.split('\n').map(i => i.trim()).filter(i => i.length > 0)
      : [];

    if (form.isPhone && form.quantity !== imeis.length) {
      setValidationMsg(`IMEI Serial Mismatch: You set stock Qty to ${form.quantity} but provided ${imeis.length} IMEI rows.`);
      return;
    }

    const payload = {
      name: form.name.trim(),
      model: form.model.trim(),
      brand: form.brand,
      category: form.category,
      costPrice: Number(form.costPrice),
      sellingPrice: Number(form.sellingPrice),
      quantity: Number(form.quantity),
      imeis,
      color: form.color.trim() || 'Multicolor',
      ram: form.ram,
      storage: form.storage,
      isPhone: form.isPhone,
      lowStockLimit: Number(form.lowStockLimit),
    };

    if (editingId) {
      updateProduct({
        ...payload,
        id: editingId,
        status: 'In Stock', // status is handled by context state
      });
      alert('Product database registry updated successfully.');
    } else {
      addProduct(payload);
      alert('New product submitted to ERP system catalog.');
    }

    setIsAddOpen(false);
    setForm(defaultFormState);
  };

  // Delete Action
  const handleDeleteProduct = (id: string, name: string) => {
    if (confirm(`Are you sure you want to permanently remove "${name}" from stock catalog?`)) {
      deleteProduct(id);
    }
  };

  // Inline dynamic category builder
  const submitInlineCat = () => {
    if (newCatName.trim()) {
      addCategory(newCatName.trim());
      setForm(prev => ({ ...prev, category: newCatName.trim() }));
      setNewCatName('');
      setIsAddingCat(false);
    }
  };

  // Inline dynamic brand builder
  const submitInlineBrand = () => {
    if (newBrandName.trim()) {
      addBrand(newBrandName.trim());
      setForm(prev => ({ ...prev, brand: newBrandName.trim() }));
      setNewBrandName('');
      setIsAddingBrand(false);
    }
  };

  // FILTERING ENGINE
  const filteredProducts = products.filter(p => {
    const pName = p.name.toLowerCase();
    const pModel = p.model.toLowerCase();
    const matchSearch = pName.includes(searchTerm.toLowerCase()) || pModel.includes(searchTerm.toLowerCase()) || p.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchBrand = selectedBrand === 'All' || p.brand === selectedBrand;
    const matchCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchStatus = selectedStatus === 'All' || p.status === selectedStatus;

    return matchSearch && matchBrand && matchCategory && matchStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* 1. Header controls and summary counters */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-600/10 border border-indigo-500/20 rounded-xl text-indigo-400">
            <Layers size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Catalog Registry Directory</h2>
            <p className="text-[11px] text-slate-400">Currently hosting <strong className="text-indigo-400 font-bold font-mono">{products.length}</strong> items • Total Stock: <strong className="text-emerald-400 font-bold font-mono">{products.reduce((acc, x) => acc + x.quantity, 0)}</strong> units</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => setIsBulkOpen(true)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white rounded-lg text-xs font-bold font-mono flex items-center gap-1.5 border border-slate-705 cursor-pointer shadow-md transition-all active:scale-95"
          >
            <Upload size={14} className="text-indigo-400" />
            <span>Excel / CSV Bulk Import</span>
          </button>
          
          <button
            onClick={openAddModal}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-lg shadow-indigo-500/20 active:scale-95"
          >
            <Plus size={15} />
            <span>Add Single Device</span>
          </button>
        </div>
      </div>

      {/* 2. Search & Filter Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
          <input
            type="text"
            placeholder="Search brand, model, specs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-bold whitespace-nowrap">Brand:</span>
          <select
            value={selectedBrand}
            onChange={(e) => setSelectedBrand(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Brands</option>
            {brands.map(b => (
              <option key={b.id} value={b.name}>{b.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-bold whitespace-nowrap">Category:</span>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Categories</option>
            {categories.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-bold whitespace-nowrap">Status:</span>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
          >
            <option value="All">All Statuses</option>
            <option value="In Stock">In Stock</option>
            <option value="Low Stock">Low Stock</option>
            <option value="Out of Stock">Out of Stock</option>
          </select>
        </div>
      </div>

      {/* 3. Main Catalog Database Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-slate-950/20">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Item Details / Specs</th>
                <th className="py-3 px-4 font-normal">Brand</th>
                <th className="py-3 px-4 font-normal">Category</th>
                <th className="py-3 px-4 text-right">Cost Price</th>
                <th className="py-3 px-4 text-right">Selling Price</th>
                <th className="py-3 px-4 text-right">Markup Marg.</th>
                <th className="py-3 px-4 text-right">Stock Qty</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Catalog actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {filteredProducts.map((p) => {
                const costPriceVal = p.costPrice ?? 0;
                const sellingPriceVal = p.sellingPrice ?? 0;
                const markup = sellingPriceVal - costPriceVal;
                const profitMarginPercent = costPriceVal > 0 ? Math.round((markup / costPriceVal) * 100) : 0;
                
                let stockBadge = 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
                if (p.status === 'Out of Stock') {
                  stockBadge = 'bg-rose-500/10 text-rose-400 border border-rose-500/25';
                } else if (p.status === 'Low Stock') {
                  stockBadge = 'bg-amber-500/10 text-amber-400 border border-amber-500/20';
                }

                return (
                  <tr key={p.id} className="hover:bg-slate-800/15 text-slate-300">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-lg shrink-0 ${p.isPhone ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'bg-slate-800 border border-slate-700 text-slate-400'}`}>
                          {p.isPhone ? <Smartphone size={15} /> : <Layers size={15} />}
                        </div>
                        <div>
                          <span className="font-bold text-slate-100 hover:text-indigo-400 transition-colors block text-[13px]">{p.name}</span>
                          <span className="font-mono text-[9px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                            ID: <strong className="font-semibold text-slate-300 font-mono">{p.id}</strong> 
                            {p.isPhone && (
                              <>
                                <span>•</span>
                                <span className="bg-slate-800 px-1 py-0.5 rounded text-[9px] font-semibold text-slate-400">{p.ram}/{p.storage} • {p.color}</span>
                              </>
                            )}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-medium">{p.brand}</td>
                    <td className="py-3 px-4 text-slate-400 font-medium">{p.category}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-300">
                      {settings.currency}
                      {costPriceVal.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-100">
                      {settings.currency}
                      {sellingPriceVal.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-emerald-400 font-bold font-mono">
                        +{settings.currency}
                        {(markup).toLocaleString()}
                      </span>
                      <span className="block text-[9px] text-slate-500 font-semibold">({profitMarginPercent}%)</span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold">
                      <span className={p.quantity <= p.lowStockLimit ? 'text-amber-400 font-extrabold' : 'text-slate-200'}>
                        {p.quantity} Units
                      </span>
                      {p.isPhone && (
                        <span className="block text-[9px] text-slate-500 font-normal">
                          {p.imeis.length} IMEIs available
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${stockBadge}`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => openEditModal(p)}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 hover:text-white text-slate-400 transition-colors cursor-pointer"
                          title="Edit Info"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id, p.name)}
                          className="p-1 rounded bg-slate-800 hover:bg-red-950 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                          title="Delete Product"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredProducts.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500 text-xs">
                    No items in catalog matched your filter search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. Single Product Add / Edit Modal Dial */}
      {isAddOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-800 flex justify-between items-center bg-slate-950/30">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Smartphone className="text-indigo-400" size={18} />
                <span>{editingId ? 'Edit Product Catalog details' : 'Register New Single Device Product'}</span>
              </h3>
              <button onClick={() => setIsAddOpen(false)} className="p-1 rounded-lg hover:bg-slate-850 text-slate-400 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmitProduct} className="flex-1 overflow-y-auto p-6 space-y-4">
              
              {/* Checkbox item: Is this a Phone device? */}
              <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/40 flex items-center justify-between">
                <div>
                  <label className="text-xs font-bold text-slate-200 block">Is this a Mobile Phone device?</label>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Will require serial IMEI registrations and specification inputs</span>
                </div>
                <input
                  type="checkbox"
                  name="isPhone"
                  checked={form.isPhone}
                  onChange={handleFormChange}
                  className="w-4 h-4 text-indigo-600 border-slate-800 rounded focus:ring-indigo-500 bg-slate-950"
                />
              </div>

              {/* Grid 1 Column Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Product Name</label>
                  <input
                    type="text"
                    name="name"
                    required
                    placeholder="e.g. iPhone 15 Pro Max Purple"
                    value={form.name}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Model SKU Designation</label>
                  <input
                    type="text"
                    name="model"
                    required
                    placeholder="e.g. S24 Ultra, K40-Pro, Nano-L"
                    value={form.model}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Grid 2 Select list Dynamic / Custom add triggers */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Brand Manufacturer</label>
                    <button
                      type="button"
                      onClick={() => setIsAddingBrand(!isAddingBrand)}
                      className="text-[9px] text-indigo-400 hover:text-indigo-300 font-bold"
                    >
                      {isAddingBrand ? 'Cancel' : '+ New Brand'}
                    </button>
                  </div>
                  {isAddingBrand ? (
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        placeholder="New brand"
                        value={newBrandName}
                        onChange={(e) => setNewBrandName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="button"
                        onClick={submitInlineBrand}
                        className="px-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <select
                      name="brand"
                      value={form.brand}
                      onChange={handleFormChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none"
                    >
                      {brands.map(b => (
                        <option key={b.id} value={b.name}>{b.name}</option>
                      ))}
                    </select>
                  )}
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Category Sector</label>
                    <button
                      type="button"
                      onClick={() => setIsAddingCat(!isAddingCat)}
                      className="text-[9px] text-indigo-400 hover:text-indigo-300 font-bold"
                    >
                      {isAddingCat ? 'Cancel' : '+ New Cat'}
                    </button>
                  </div>
                  {isAddingCat ? (
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        placeholder="Category"
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="button"
                        onClick={submitInlineCat}
                        className="px-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
                      >
                        Save
                      </button>
                    </div>
                  ) : (
                    <select
                      name="category"
                      value={form.category}
                      onChange={handleFormChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 focus:outline-none"
                    >
                      {categories.map(c => (
                        <option key={c.id} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  )}
                </div>
              </div>

              {/* Smartphone specifications triggers */}
              {form.isPhone && (
                <div className="bg-slate-950/20 p-4 rounded-xl border border-slate-850/60 grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wide block mb-1">RAM Capacity</label>
                    <select
                      name="ram"
                      value={form.ram}
                      onChange={handleFormChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300"
                    >
                      <option value="64MB">64MB</option>
                      <option value="4GB">4GB</option>
                      <option value="6GB">6GB</option>
                      <option value="8GB">8GB</option>
                      <option value="12GB">12GB</option>
                      <option value="16GB">16GB</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Storage Spc</label>
                    <select
                      name="storage"
                      value={form.storage}
                      onChange={handleFormChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300"
                    >
                      <option value="128MB">128MB</option>
                      <option value="64GB">64GB</option>
                      <option value="128GB">128GB</option>
                      <option value="256GB">256GB</option>
                      <option value="512GB">512GB</option>
                      <option value="1TB">1TB</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Color Variant</label>
                    <input
                      type="text"
                      name="color"
                      placeholder="Titanium, Coral Red"
                      value={form.color}
                      onChange={handleFormChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 block"
                    />
                  </div>
                </div>
              )}

              {/* Cost, Selling, Stock Limits */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="col-span-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Cost Price (BDT)</label>
                  <input
                    type="number"
                    name="costPrice"
                    required
                    placeholder="Buying Cost"
                    value={form.costPrice || ''}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                  />
                </div>
                <div className="col-span-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Retail Price (BDT)</label>
                  <input
                    type="number"
                    name="sellingPrice"
                    required
                    placeholder="MSRP"
                    value={form.sellingPrice || ''}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono font-bold text-emerald-400"
                  />
                </div>
                <div className="col-span-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Stock Qty</label>
                  <input
                    type="number"
                    name="quantity"
                    required
                    placeholder="Counts"
                    value={form.quantity || 0}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-bold"
                  />
                </div>
                <div className="col-span-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wide block mb-1">Low Alert Qty</label>
                  <input
                    type="number"
                    name="lowStockLimit"
                    required
                    placeholder="Threshold Limit"
                    value={form.lowStockLimit}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-bold"
                  />
                </div>
              </div>

              {/* IMEI list inputs (if phone) */}
              {form.isPhone && (
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-bold uppercase text-slate-400">
                    <label>IMEI Numbers list (One number per row)</label>
                    <span className="text-indigo-400 font-extrabold">Requirement: {form.quantity} rows</span>
                  </div>
                  <textarea
                    name="imeisString"
                    rows={4}
                    placeholder="IMEI-XXXXXXXXXXXX-1&#10;IMEI-XXXXXXXXXXXX-2"
                    value={form.imeisString}
                    onChange={handleFormChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500 leading-normal"
                  />
                </div>
              )}

              {/* Validation panel message */}
              {validationMsg && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 rounded-lg p-3 text-xs flex gap-2 items-center">
                  <AlertTriangle size={14} className="shrink-0" />
                  <span>{validationMsg}</span>
                </div>
              )}

              {/* Control Buttons */}
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2 border border-slate-800 bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs font-bold transition-all"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-shadow shadow-md shadow-indigo-500/20"
                >
                  {editingId ? 'Save Database changes' : 'Register Product'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* 5. Bulk spreadsheet Import Modal dialog */}
      <BulkImportDialog
        isOpen={isBulkOpen}
        onClose={() => setIsBulkOpen(false)}
        onImport={(imported) => {
          bulkImportProducts(imported);
          setIsBulkOpen(false);
        }}
      />

    </div>
  );
};
