/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  TrendingUp,
  Smartphone,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  PackageCheck,
  ShoppingCart,
  CalendarDays
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Dashboard: React.FC = () => {
  const { sales, products, accounts, settings } = useApp();

  // 1. CALCULATIONS FOR KPI DASHBOARD CARDS
  const todayStr = new Date().toISOString().split('T')[0];
  const yesterdayStr = (() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  })();

  const filterSalesByDate = (date: string) => sales.filter((s) => s.date === date);

  const todaySalesObj = filterSalesByDate(todayStr);
  const todayRevenue = todaySalesObj.reduce((sum, s) => sum + (s.total ?? 0), 0);
  const todayTxCount = todaySalesObj.length;

  const yesterdaySalesObj = filterSalesByDate(yesterdayStr);
  const yesterdayRevenue = yesterdaySalesObj.reduce((sum, s) => sum + (s.total ?? 0), 0);

  // Growth calculation vs yesterday
  const revGrowth = (() => {
    if (yesterdayRevenue === 0) return todayRevenue > 0 ? 100 : 0;
    return Math.round(((todayRevenue - yesterdayRevenue) / yesterdayRevenue) * 100);
  })();

  // Current Month Target Calculation
  const currentMonthPrefix = todayStr.substring(0, 7); // "YYYY-MM"
  const thisMonthSales = sales.filter((s) => s.date && s.date.startsWith(currentMonthPrefix));
  const thisMonthRevenue = thisMonthSales.reduce((sum, s) => sum + (s.total ?? 0), 0);
  const targetPercentage = Math.min(100, Math.round((thisMonthRevenue / (settings.targetMonthlySales || 1500000)) * 100));

  // Device Stocks
  const deviceProducts = products.filter((p) => p.isPhone);
  const totalDeviceStockCount = deviceProducts.reduce((sum, p) => sum + (p.quantity ?? 0), 0);
  const lowStockDeviceCount = deviceProducts.filter((p) => p.status === 'Low Stock' || p.status === 'Out of Stock').length;

  // Capital Assets
  const currentCapitalPool = accounts.reduce((sum, a) => sum + (a.balance ?? 0), 0);

  // --- 2. MULTI-DAY HISTORICAL PERFORMANCE FOR SVG CHART ---
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().split('T')[0];
  });

  const chartData = last7Days.map((dStr) => {
    const dailySec = sales.filter((s) => s.date === dStr);
    const rev = dailySec.reduce((sum, s) => sum + (s.total ?? 0), 0);
    const count = dailySec.length;
    const nameStr = new Date(dStr).toLocaleDateString('en-US', { weekday: 'short' });
    return { date: dStr, name: nameStr, revenue: rev, count };
  });

  const maxRevenue = Math.max(...chartData.map((d) => d.revenue), 10000);

  return (
    <div className="space-y-6">
      {/* 1. Stat cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
        {/* Today's Sales Revenue Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg shadow-slate-950/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-xl group-hover:bg-indigo-500/10 transition-colors"></div>
          <div className="flex items-center justify-between mb-3 text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Today's Transactions</span>
            <div className="p-2.5 bg-indigo-600/10 border border-indigo-500/25 rounded-xl text-indigo-400">
              <ShoppingCart size={18} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-100 font-mono tracking-tight">
            {settings.currency}
            {(todayRevenue ?? 0).toLocaleString()}
          </h3>
          <p className="text-slate-400 text-xs mt-1 leading-normal flex items-center gap-1.5 font-medium">
            <span className="text-slate-200 font-semibold">{todayTxCount} invoices</span> • 
            {revGrowth >= 0 ? (
              <span className="text-emerald-400 flex items-center font-bold">
                <ArrowUpRight size={14} />+{revGrowth}% vs yesterday
              </span>
            ) : (
              <span className="text-rose-400 flex items-center font-bold">
                <ArrowDownRight size={14} />
                {revGrowth}% vs yesterday
              </span>
            )}
          </p>
        </div>

        {/* Monthly Target Progress Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg shadow-slate-950/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl group-hover:bg-emerald-500/10 transition-colors"></div>
          <div className="flex items-center justify-between mb-3 text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Monthly Sales Target</span>
            <div className="p-2.5 bg-emerald-600/10 border border-emerald-500/25 rounded-xl text-emerald-400">
              <TrendingUp size={18} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-100 font-mono tracking-tight">
            {targetPercentage}%
          </h3>
          <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden border border-slate-700/50">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                targetPercentage >= 100
                  ? 'bg-emerald-500'
                  : targetPercentage >= 60
                  ? 'bg-indigo-500'
                  : 'bg-amber-500'
              }`}
              style={{ width: `${targetPercentage}%` }}
            ></div>
          </div>
          <p className="text-slate-400 text-xs mt-2 leading-tight">
            Revenue: <span className="text-slate-200 font-bold">{settings.currency}{(thisMonthRevenue ?? 0).toLocaleString()}</span> / {settings.currency}{(settings.targetMonthlySales ?? 1500000).toLocaleString()}
          </p>
        </div>

        {/* Active Device Stock Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg shadow-slate-950/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-xl group-hover:bg-purple-500/10 transition-colors"></div>
          <div className="flex items-center justify-between mb-3 text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Phones In stock</span>
            <div className="p-2.5 bg-purple-600/10 border border-purple-500/25 rounded-xl text-purple-400">
              <Smartphone size={18} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-100 font-mono tracking-tight">
            {totalDeviceStockCount} <span className="text-xs text-slate-400">units</span>
          </h3>
          <p className="text-slate-400 text-xs mt-2 flex items-center gap-1.5">
            {lowStockDeviceCount > 0 ? (
              <span className="text-rose-400 bg-rose-500/10 border border-rose-500/20 px-1.5 py-0.5 rounded flex items-center gap-1 font-semibold text-[10px]">
                <AlertTriangle size={12} />
                {lowStockDeviceCount} devices low / out
              </span>
            ) : (
              <span className="text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded flex items-center gap-1 font-semibold text-[10px]">
                <ShieldCheck size={12} /> Stock levels healthy
              </span>
            )}
          </p>
        </div>

        {/* Capital Assets Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg shadow-slate-950/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-pink-500/5 rounded-full blur-xl group-hover:bg-pink-500/10 transition-colors"></div>
          <div className="flex items-center justify-between mb-3 text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Estimated Liquid Wealth</span>
            <div className="p-2.5 bg-pink-600/10 border border-pink-500/25 rounded-xl text-pink-400">
              <DollarSign size={18} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-100 font-mono tracking-tight">
            {settings.currency}
            {(currentCapitalPool ?? 0).toLocaleString()}
          </h3>
          <p className="text-slate-400 text-xs mt-2 leading-none">
            Sum of cash, banks & MFS transfers
          </p>
        </div>
      </div>

      {/* 2. Visual charts & Daily Performance Segment */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Sales Performance SVG chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg xl:col-span-2 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h4 className="text-sm font-bold text-slate-100">Daily Sales Performance (7-Day Metric)</h4>
              <p className="text-[11px] text-slate-400">Consolidated gross value tracking per day</p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold bg-slate-950/50 border border-slate-800 px-2.5 py-1 rounded-lg">
              <CalendarDays size={14} className="text-indigo-400" />
              <span>June 2026</span>
            </div>
          </div>

          {/* SVG Chart Drawing */}
          <div className="h-64 w-full relative flex items-end justify-between px-2 pt-6">
            {/* Horizontal Grid lines */}
            <div className="absolute inset-x-0 top-6 bottom-6 flex flex-col justify-between pointer-events-none opacity-20">
              <div className="border-t border-slate-700 w-full"></div>
              <div className="border-t border-slate-700 w-full"></div>
              <div className="border-t border-slate-700 w-full"></div>
              <div className="border-t border-slate-700 w-full"></div>
            </div>

            {/* Render Bars and Labels */}
            {chartData.map((d, index) => {
              const activePercentage = maxRevenue > 0 ? (d.revenue / maxRevenue) * 85 : 0; // standard bar height scale
              const isToday = d.date === todayStr;

              return (
                <div key={index} className="flex flex-col items-center flex-1 group z-10">
                  {/* Tooltip on Hover */}
                  <div className="absolute bottom-20 bg-slate-950 text-white border border-indigo-500/30 text-[10px] px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity shadow-xl z-20 font-mono text-center">
                    <p className="font-bold text-slate-100">{d.name} : ৳{(d.revenue ?? 0).toLocaleString()}</p>
                    <p className="text-[9px] text-indigo-400 font-semibold">{d.count} invoices</p>
                  </div>

                  {/* The bar */}
                  <div className="w-10 sm:w-12 bg-slate-850 rounded-lg flex items-end h-44 overflow-hidden border border-slate-800">
                    <div
                      className={`w-full rounded-b-lg rounded-t transition-all duration-700 ${
                        isToday
                          ? 'bg-gradient-to-t from-indigo-700 to-indigo-400 hover:from-indigo-600 hover:to-indigo-300'
                          : 'bg-gradient-to-t from-slate-700 to-indigo-500/50 hover:from-slate-600 hover:to-indigo-500/80'
                      }`}
                      style={{ height: `${activePercentage}%` }}
                    ></div>
                  </div>

                  {/* Day label */}
                  <span className={`text-[10px] font-bold mt-2 ${isToday ? 'text-indigo-400 font-extrabold' : 'text-slate-400'}`}>
                    {d.name}
                  </span>
                  {/* value text */}
                  <span className="text-[9px] font-semibold font-mono text-slate-500 mt-0.5 truncate max-w-[65px]">
                    ৳{d.revenue >= 1000 ? `${(d.revenue / 1000).toFixed(0)}k` : d.revenue}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. Phone Inventory Overview panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-sm font-bold text-slate-100">Live Phone Stock Levels</h4>
                <p className="text-[11px] text-slate-400">Color-coded models and balances left</p>
              </div>
              <Smartphone size={16} className="text-indigo-400" />
            </div>

            {/* List and Stock Level bars */}
            <div className="space-y-4 max-h-[220px] overflow-y-auto pr-1 select-none scrollbar-thin scrollbar-thumb-slate-800">
              {deviceProducts.map((p) => {
                // Stock color thresholds
                const percentLeft = Math.min(100, Math.round((p.quantity / 15) * 100)); // normalized out of 15 max model box storage
                let progressColor = 'bg-emerald-500';
                let textColor = 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20';

                if (p.quantity === 0) {
                  progressColor = 'bg-rose-600';
                  textColor = 'text-rose-400 bg-rose-500/10 border border-rose-500/20';
                } else if (p.quantity <= p.lowStockLimit) {
                  progressColor = 'bg-amber-500';
                  textColor = 'text-amber-400 bg-amber-500/10 border border-amber-500/15';
                }

                return (
                  <div key={p.id} className="text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <div className="truncate max-w-[170px] pr-2">
                        <span className="font-bold text-slate-200">{p.name}</span>
                        <p className="text-[9px] text-slate-400 font-semibold">{p.color} • {p.storage}</p>
                      </div>
                      <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] whitespace-nowrap ${textColor}`}>
                        {p.quantity} left
                      </span>
                    </div>
                    {/* Tiny Progress gauge */}
                    <div className="w-full bg-slate-800 rounded-full h-1 overflow-hidden">
                      <div className={`h-full rounded-full ${progressColor}`} style={{ width: `${percentLeft}%` }}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Downside Row: Low stock details and recent sales list */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Low Stock alert center */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                <AlertTriangle size={15} className="text-amber-400" />
                Critical Stock Alerts ({products.filter((p) => p.status === 'Low Stock' || p.status === 'Out of Stock').length})
              </h4>
              <p className="text-[11px] text-slate-400">Items requiring ordering/restocking actions</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-850 text-slate-400 font-bold">
                  <th className="py-2.5 px-3">Device/Item</th>
                  <th className="py-2.5 px-3">Brand</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-right">Current Stock</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {products
                  .filter((p) => p.status === 'Low Stock' || p.status === 'Out of Stock')
                  .slice(0, 5)
                  .map((p) => (
                    <tr key={p.id} className="hover:bg-slate-800/20 text-slate-300">
                      <td className="py-2 px-3 font-semibold text-slate-200">
                        {p.name}
                        <span className="block text-[9px] text-slate-400 font-normal">{p.model}</span>
                      </td>
                      <td className="py-2 px-3 text-slate-400">{p.brand}</td>
                      <td className="py-2 px-3 text-center">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            p.status === 'Out of Stock'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/25'
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-bold text-slate-100 font-mono">
                        {p.quantity} Units (Limit: {p.lowStockLimit})
                      </td>
                    </tr>
                  ))}
                {products.filter((p) => p.status === 'Low Stock' || p.status === 'Out of Stock').length === 0 && (
                  <tr>
                    <td colSpan={4} className="text-center py-6 text-slate-400">
                      All products have secure healthy reserves. Good job.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent sales history desk */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-sm font-bold text-slate-100">Recent POS Sales Logs</h4>
              <p className="text-[11px] text-slate-400">Real-time status of outgoing counter invoices</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-850 text-slate-400 font-bold">
                  <th className="py-2.5 px-3">Invoice</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3 text-center">Payment System</th>
                  <th className="py-2.5 px-3 text-right">Invoice Sum</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {sales.slice(0, 5).map((sale) => {
                  let paybadge = 'bg-slate-800 border-slate-700 text-slate-300';
                  const pName = sale.paymentMethod.toString();
                  if (pName.includes('bKash')) paybadge = 'bg-pink-500/15 border border-pink-500/30 text-pink-400';
                  else if (pName.includes('Nagad')) paybadge = 'bg-orange-500/15 border border-orange-500/30 text-orange-400';
                  else if (pName.includes('BRAC') || pName.includes('Bank')) paybadge = 'bg-blue-500/15 border border-blue-500/30 text-blue-400';
                  else if (pName.includes('Cash')) paybadge = 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-400';

                  return (
                    <tr key={sale.id} className="hover:bg-slate-800/20 text-slate-300">
                      <td className="py-2 px-3 font-mono font-bold text-indigo-400">{sale.invoiceNo}</td>
                      <td className="py-2 px-3 text-slate-400 font-mono">{sale.date}</td>
                      <td className="py-2 px-3">
                        <span className="block font-semibold text-slate-200">{sale.customerName}</span>
                        <span className="text-[9px] text-slate-400 font-mono">{sale.customerPhone}</span>
                      </td>
                      <td className="py-2 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${paybadge}`}>
                          {sale.paymentMethod.toString().split(' ')[0]}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-bold text-slate-100 font-mono">
                        {settings.currency}
                        {(sale.total ?? 0).toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
