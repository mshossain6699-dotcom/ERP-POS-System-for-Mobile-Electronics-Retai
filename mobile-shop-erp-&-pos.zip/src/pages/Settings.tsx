/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings as SettingsIcon, Save, RefreshCcw, Database, AlertCircle, Sparkles, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Settings: React.FC = () => {
  const { settings, updateSettings, resetAllDatabaseData } = useApp();

  const [shopName, setShopName] = useState(settings.shopName);
  const [description, setDescription] = useState(settings.description);
  const [address, setAddress] = useState(settings.address);
  const [contactNo, setContactNo] = useState(settings.contactNo);
  const [currency, setCurrency] = useState(settings.currency);
  const [vatPercent, setVatPercent] = useState(settings.vatPercent);
  const [invoiceFooter, setInvoiceFooter] = useState(settings.invoiceFooter);

  const [notification, setNotification] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      shopName: shopName.trim(),
      description: description.trim(),
      address: address.trim(),
      contactNo: contactNo.trim(),
      currency,
      vatPercent: Number(vatPercent),
      invoiceFooter: invoiceFooter.trim()
    });

    setNotification('Shop business configurations were safely updated.');
    setTimeout(() => setNotification(''), 4000);
  };

  const handleReset = () => {
    const doubleCheck = window.confirm(
      'WARING: This will erase all sales invoices, cash ledger histories, and catalog additions. Reset now?'
    );
    if (doubleCheck) {
      resetAllDatabaseData();
      alert('All files cleared. Default mock databases restored.');
      // Reload page to re-establish mock catalog variables safely
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      
      {/* Save Notification alert banner */}
      {notification && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3.5 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 size={16} />
          <span>{notification}</span>
        </div>
      )}

      {/* 1. Header component */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-505 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
            <SettingsIcon size={22} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100">Global ERP Configurations</h2>
            <p className="text-[11px] text-slate-400">Manage business coordinates, invoice printers, legal taxes and data backups</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Left side Form span-2 */}
        <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <form onSubmit={handleSave} className="space-y-4">
            
            <span className="text-[10px] uppercase font-bold text-indigo-400 block border-b border-slate-800 pb-2">Business General Profile</span>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Store / Shop Name</label>
                <input
                  type="text"
                  required
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-205 text-slate-100 focus:outline-none focus:border-indigo-500 font-bold"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Company Primary Line</label>
                <input
                  type="text"
                  required
                  value={contactNo}
                  onChange={(e) => setContactNo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-205 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Slogan Tagline Description</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-205 text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Showroom street physical Address</label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-205 text-slate-100 focus:outline-none"
              />
            </div>

            <span className="text-[10px] uppercase font-bold text-indigo-400 block border-b border-slate-800 pt-3 pb-2">Billing and Invoice configs</span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Currency Symbol</label>
                <input
                  type="text"
                  required
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-205 text-slate-100 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">VAT Surcharge percent (%)</label>
                <input
                  type="number"
                  required
                  value={vatPercent}
                  onChange={(e) => setVatPercent(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-205 text-slate-100 focus:outline-none font-mono"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Invoice Receipt Footer Note</label>
              <textarea
                rows={3}
                required
                value={invoiceFooter}
                onChange={(e) => setInvoiceFooter(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-205 text-slate-100 focus:outline-none"
              />
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shadow-indigo-500/20 active:scale-95 cursor-pointer"
              >
                <Save size={14} />
                <span>Save ERP Settings</span>
              </button>
            </div>

          </form>
        </div>

        {/* Right side diagnostics block */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg h-fit">
          <span className="text-[10px] uppercase font-bold text-rose-455 text-rose-400 block border-b border-slate-800 pb-2 flex items-center gap-1">
            <Database size={13} />
            <span>ERP Database Backups Desk</span>
          </span>

          <p className="text-[11px] text-slate-400 leading-normal">
            Your Mobile Shop ERP is storing transaction ledgers, IMEI serials barcodes and client databases securely inside sandboxed offline browser indices.
          </p>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-850/60 text-[10px] text-indigo-400 font-medium font-mono flex items-center gap-1.5">
            <Sparkles size={11} />
            <span>Database state: VERIFIED SUCCESSFUL</span>
          </div>

          <div className="border-t border-slate-800/80 pt-4 space-y-2">
            <button
              onClick={handleReset}
              className="w-full py-2 bg-red-600/10 hover:bg-red-650 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/15 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
            >
              <RefreshCcw size={13} />
              <span>Reset & Purge All Data</span>
            </button>
            <p className="text-[9px] text-slate-500 text-center leading-normal mt-1">
              Actions are final. Erased files cannot be recovered.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
