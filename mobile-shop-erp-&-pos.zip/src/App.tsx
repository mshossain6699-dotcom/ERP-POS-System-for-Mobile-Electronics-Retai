/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Sidebar, TabName } from './components/Sidebar';
import { Topbar } from './components/Topbar';

// Page components imports
import { Dashboard } from './pages/Dashboard';
import { POS } from './pages/POS';
import { Products } from './pages/Products';
import { IMEIManagement } from './pages/IMEIManagement';
import { Sales } from './pages/Sales';
import { Purchases } from './pages/Purchases';
import { Contacts } from './pages/Contacts';
import { Accounting } from './pages/Accounting';
import { Expenses } from './pages/Expenses';
import { Coupons } from './pages/Coupons';
import { StockAdjustment } from './pages/StockAdjustment';
import { Partners } from './pages/Partners';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';

function MainAppContent() {
  const [currentTab, setCurrentTab] = useState<TabName>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Render correct panel module on active state switcher
  const renderActiveTabPanel = () => {
    switch (currentTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'pos':
        return <POS />;
      case 'products':
        return <Products />;
      case 'imeis':
        return <IMEIManagement />;
      case 'sales':
        return <Sales />;
      case 'purchases':
        return <Purchases />;
      case 'contacts':
        return <Contacts />;
      case 'accounts':
        return <Accounting />;
      case 'expenses':
        return <Expenses />;
      case 'coupons':
        return <Coupons />;
      case 'stock-adjustment':
        return <StockAdjustment />;
      case 'partners':
        return <Partners />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 font-sans text-slate-800 antialiased">
      
      {/* Structural Collapsible Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
      />

      {/* Main Panel Content Hub */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        
        {/* Dynamic header Topbar widget */}
        <Topbar currentTab={currentTab} />

        {/* Dynamic content canvas panel container */}
        <main className="flex-1 p-6 overflow-y-auto bg-slate-50 text-slate-800">
          <div className="max-w-[1600px] mx-auto space-y-6">
            {renderActiveTabPanel()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
